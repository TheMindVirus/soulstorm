This set of tools is for exporting static meshes from Blender and putting them ingame.

Here is the download link.  If anyone wants to host this somewhere else, please do and post it in this thread.

[URL]http://www.savefile.com/files/1074273[/URL]


Blender is freeware under the GNU Public license and hopefully this will open up the modeling aspect of modding DOW
to more modders.  Maybe it will even increase the longevity of DOW modding and interest in 
Relic's excellent engine in the same way Quake II and Halflife modding lived on due to the availability 
of inexpensve tools or free tools to mod those games.

So here are some screenshots of a static mesh exported from Blender (the big 3d text that says "FROM BLENDER", 

.whm file ingame in Winter Assualt

http://img231.imageshack.us/my.php?image=blenderingamels2.jpg

.whm file in the Mission Editor

http://img508.imageshack.us/my.php?image=fromblenderinmejpghv8.jpg

.sgm file in Object Editor

http://img508.imageshack.us/my.php?image=fromblenderinoejpggk6.jpg

These tools allow you to create a .whm file for use ingame and in the Mission Editor, and .sgms for use in the Object Editor.
With this capability, modders can get static mesh models ingame.  I am also working on getting animations ingame
so that modders can make units, but that version is not ready yet.

Here is how to use the tools to get your meshes ingame.  The download includes a .blend file
so you can see what your file needs in order to export properly.

To get your model ingame you will need to know how to use the following:
1) Blender version 2.42a, download at www.blender.org
2) DOW Modtools Object Editor
3) DOW Modtools Attribute Editor
4) DOW Modtools Mission Editor
5) DOW Modtools Chunky Viewer
6) How to set up proper mod folders for DOW
7) How to make textures for your model and use IBBoard's texture tool to make .rsh and .wtp texture files
   that can open in the Object Editor and ingame.

I made this program to get a file ingame using Winter Assault Modtools  Version 1.41  I have not tested any of
this on Dark Crusade.

--------------------Install Details

1) Unzip the Mudlfaps Blender Export Tools .zip file wherever you want.

--------------------Blender Details

2) Model something in Blender (lots of tutorials on the web on how to do this, or use Mudflaps_whm_to_x_converter to get a .x file from DOW, or use a .x file from the Example Files folder, missile.x is the fastest)
    a) make sure that the faces are tris only, no quads
    b) the model can have only one mesh
    c) the vertexes in the mesh need to be parented to bones in an armature
    d) the vertexes in the mesh cannot be parented to the root bone of your armature or that last bone in your armature (see the .blend file included)
3) Export your mesh to a .x file using the Blender Export DirectX(.x) function in the User Preferences/File menu.  See the screenshot below
   for the corrext export settings.

   Screenshot of .x file export screen from Blender

http://img508.imageshack.us/my.php?image=directxexportscreenjpgwg9.jpg


-------------------Mudflap Conversion Tools Details


4) Use the Mudflaps_x_to_whm_converter.exe to convert your .x file to .whm.  Doubleclick on it and the
   top of the file browser boxes will tell you what you need to do as follows:
    a) Select a .x file to convert
    b) Save as .whm file.------------Browse to save it in the following path for your mod (my mod is "nurgling_mod" as an example) \THQ\Dawn of War\nurgling_mod\data_whm\High\art\ebps\environment\all\yourfile.whm  
    c) Select the texture file that applies to your model.  This file must in your art/ebps/ mod path.  you can select a .wtp, .rsh, or .rtx file.
5) Wait for the file to convert.  It takes about 1-minute per 200 vertexes in your model.  The "blender_text_scaled.x" model in the download
   takes about 10 minutes, missile.x takes about 1 minute.
6) When the program shuts down your .whm file is ready.  Open it with the DOW Modtools chunky viewer to see if it opens
   correctly and if it looks right.
7) Convert your .whm to .sgm using the tool --  Mudflaps_whm_to_sgm_converter_for_blender_export.exe
   Follow the instructions on top of the file browser boxes
     a) Select a .whm file to convert
     b) save as a .sgm file (with same name as your .whm file) in the following path -- \THQ\Dawn of War\ModTools\DataGeneric\Nurgling_Mod\Art\EBPs\races\chaos\troops\yourfile.sgm
8)  When the program shuts down your file is ready.  This program is fast.  open your .sgm with the Chunky Viewer to make sure it opens correctly.

------------------Object Editor Details

9)  Open the Object Editor
10) On the "File" menu select "new", open your .sgm.  Your model should appear.  YAY!
11) Close the Object Editor, when you do this, it will create a .whe for your file at: \THQ\Dawn of War\nurgling_mod\data\Art\EBPs\Races\chaos\troops\yourfile.whe
12  Move your .whe to \THQ\Dawn of War\nurgling_mod\data_whm\High\art\ebps\environment\all\yourfile.whe
    (that is the same folder that has your .whm.  .whm and .whe always need to be together and have the same name)

------------------Attribute Editor Details

13)  Now is time make your model int an entity the game can recognize, you need the Attribute Editor for that.
14) Open the Attribute Editor
15) Open your mod in the Attribute Editor (lots of other tutorials for this)
16) create a new entity (like "blender_text" in the screenshot below)
17) under entity_blueprint_ext/animator ---- enter the path for your .whm (see screenshot below, "blender_text_from_execut" as example.

Attribute Editor Screenshot

http://img231.imageshack.us/my.php?image=aescreenshotjpgvo1.jpg




18) save (makes a .lua of your entity)
19) save binary (makes a .rgd of your entity)
20) ignore perforce message

------------------Mission Editor Details

21) Now its time to put your entity in a Map
22) Open the Mission Editor (lots of tutorials on this)
23) Place your entity on your scenario and save it.

-----------------Impress Your Friends Details 

24) Play your scenario with your new model, ingame.

-----------Done!---------

Next Steps for tools:

1) Fix bones
2) Enable Animations
3) Create Markers
4) Convert Multiple Meshes from one file

Other tools:

I have also included my other conversion tools in this download.  Readmes are in the .zip file.



Disclaimers:

These tools are in no way endorsed by Relic, THQ, or Games Workshop.  Although the Chunky Viewer was 
very helping for understanding the chunk information.
The code for these tools can be read in the associated .py file using Python 2.4.
These tools are open source for any non-commercial purpose.
If you have any questions please feel free to email Mudflap at transhuman_space@yahoo.com
The maker of this tool is in no way responsible for any computer problems that users may have 
when using this tool, Blender, Python, or IBBoard's Texture Tool.
This tool is in Beta form and created by a hobbyist using computers with 
Intel processors and may not work as intended on all systems.