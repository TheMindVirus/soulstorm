Mudflap's WHM to X converter
Version 1.0 Beta
by Mudflap
http://games.groups.yahoo.com/group/nurglings/


Description:  This is a tool that allows you to extract mesh data from WHM files from 
Dawn of War, Winter Assault, and Dark Crusade.  The tool works on units, environment models,
like Mission Editor objects, and structures.  It only extracts mesh data and uv data.
It cannot extract animation or markers....yet The tool creates a .x file.  X format files
can be opened in Milkshape, Blender, and Ultimate Unwrap 3d, among others.  


What to do:

1) use the DOW modtools Mod Packager to extract whm files from WXPData-Whm-High.sga, W40kData-Whm-High.sga, or DXP2Data-Whm-High.sga files.  

2) Save the zip file wherever you want the tool to go.  Open the Mudflaps_WHM_to_X_Converter folder
   then doubleclick on Mudflaps_WHM_to_X_Converter.exe.
3) Dialog box will ask you what .WHM file you want to convert.
4) Dialog box will ask what .X file you want to save to.
5) IMPORTANT!!!!! ---- Open your new .X file in Notepad and save it.  Not sure why this is needed it just is.
6) Open your .X file in a graphic program.
7) Use Ibboards Texture Tool to convert rtx or wtp files to a texture you can use in your graphics program. 


Disclaimers

This tool is in no way endorsed by Relic, THQ, or Games Workshop.  Although the Chunky Viewer was 
very helping for understanding the chunk information.
The code for this tool can be read in the associated .py file using Python 2.4.
This tool is open source for any non-commercial purpose.
If you have any questions please feel free to email Mudflap at mudflapcentral@hotmail.com
The maker of this tool is in no way responsible for any computer problems that users may have 
when using this tool, Python, or IBBoard's Texture Tool.
This tool is in Beta form and created by a hobbyist using computers with 
Intel processors and may not work as intended on all systems.


This tool is an offshoot of an ongoing effort to make a GMAX exporter for DOW SGMs using Python.  
If you can help, please join the following forum.

http://www.dowdomains.co.uk/forums/viewforum.php?f=27



