#Script to export mesh data, mesh, meshnormals, and UV coordinates from 
# a Dawn of War .whm file write it to a .x file that can be opened in 
#Ultimate Unwrap 3d or Milkshape. 


import tkFileDialog


import Tkinter

from Tkconstants import *
Hint = Tkinter.Tk()
frame = Tkinter.Frame(Hint, relief=RIDGE, borderwidth=2)
frame.pack(fill=BOTH,expand=1)
label = Tkinter.Label(frame, text="OPEN Hint \n This tool can open .whms for troops, structures, environment, and sky models in the data/art/ebps path")
label2 = Tkinter.Label(frame, text="File Use \n The file will be saved as a .x file which can be opened in Milkshape, GMAX, Blender, and Ultimate Unwrap 3d. \n The tool exports mesh and uv data, no animation, bones, or markers...yet \n ESSENTIAL STEP \n  Open your new .x file in Notepad and save it before opening it up in a graphics program.")
label.pack(fill=X, expand=1)
label2.pack(fill=X, expand=1)
button = Tkinter.Button(frame,text="Close Hints",command=Hint.destroy)
button.pack(side=BOTTOM)

 

filetoparse = tkFileDialog.askopenfilename(filetypes=[("whm", "whm")], title = 'Choose a .whm file to convert to .x format')


 

filetowrite = tkFileDialog.asksaveasfilename(filetypes=[("x", "x")], title = 'Save exported .x file as.....', defaultextension = ".x")





#filetoparse = 'dummy_sky.whm'

#create a file to write data in

w = open(filetowrite,'w')

#------------------------Write X file header info

headerfile = open('x_file_header.txt', 'r')
headerinfo = headerfile.read()
w.write(headerinfo)
headerfile.close()

#------------------------start script




g = open(filetoparse,'rb') 
g.read()
endoffile = g.tell() - 20
g.seek(28)

burnfile = g.read(4)
burnfile_str = str(burnfile)
print burnfile_str

import struct

g.seek(24)                  #This part puts the file in the right position if there is no Burn info
if burnfile_str == 'FBIF':  #this part puts the file in right position if it has Burn Info in front If you change this make sure you change checksize_int at the end.
    g.seek(36)               
    checkFBIFsize = struct.unpack('<L', g.read(4))[0]
    checkFBIFsize_int = int(checkFBIFsize)
    burnfile_data_end = 57 + checkFBIFsize_int
    g.seek(burnfile_data_end)


#------------<<<<<<<<<<<<<<<<<Start Main Loop Here>>>>>>>>>>>>>>>>>>>>>>---------------------

for i in range(1,60): 
    checkposition = g.tell()
    checktype = g.read(4) 
    checkID = g.read(4)
    checkver = struct.unpack('<L', g.read(4))[0] 
    checksize = struct.unpack('<L', g.read(4))[0] 
    checknamesize = struct.unpack('<L', g.read(4))[0] 
    noname_position = g.tell()
    name = g.read(checknamesize)
    position = g.tell()
    oldchunk_start = g.tell()
    oldchunk_size = checksize
        
    if checknamesize == '0000':
        nextchunk = noname_position + checksize
    if checknamesize != '0000':
        nextchunk = position + checksize 
    if checktype == 'FOLD':
        if checknamesize == '0000':
            nextchunk = noname_position
        if checknamesize != '0000':
            nextchunk = position 
 
    print checkposition 
    print checktype
    print checkID
    print checkver
    print checksize
    print checknamesize
    print nextchunk

#-------------------------------------Loop Breaking Here

    if nextchunk > endoffile:
        Hint.mainloop()
        break
    if checkID == 'ANIM':
        w.close()
        Hint.mainloop()
        endofloop = g.tell()
        print 'ended at folder ANIM at byte', endofloop        
        break
#-------------------------------------End Loop Breaking



    if checkID == 'MSLC' or checkID == 'GEOM':
        whmconfirm = 'GEOM'
        meshname_for_file = str(name)
        if checkID == 'MSLC':
            whmconfirm = 'MSLC'
        g.seek(nextchunk)    
        checkposition = g.tell() 
        checktype = g.read(4) 
        checkID = g.read(4)
        checkver = struct.unpack('<L', g.read(4))[0] 
        checksize = struct.unpack('<L', g.read(4))[0] 
        checknamesize = struct.unpack('<L', g.read(4))[0] 
        noname_position = g.tell()
        name = g.read(checknamesize)
        position = g.tell()
        if checknamesize == '0000':
            nextchunk = noname_position
        if checknamesize != '0000':
            nextchunk = position 
        print 'file located at', nextchunk
        g.seek(nextchunk)
        if whmconfirm == 'MSLC':
#            g.read(17)
            g.read(17)
        mslclocation = g.tell()

#new stuff for space marine.whm
#        meshnamesize = struct.unpack('<L', g.read(4))[0] 
#        meshname = g.read(meshnamesize)
#        endmeshname = g.tell()
#        spacersize = struct.unpack('<L', g.read(4))[0] 
#        mslclocation = g.tell()

#end new stuff        

        numverts = struct.unpack('<L', g.read(4))[0]
        meshcodeaddress = g.tell()
        meshcodeaddress_str = str(meshcodeaddress)
        meshcode = struct.unpack('<L', g.read(4))[0] 
        meshcode_str = str(meshcode)
        numverts_str = str(numverts)
        numvertsend = numverts - 1
#new stuff for space marine.whm
#        g.seek(endmeshname)
#        g.read(12) for unit models
#        g.read(spacersize)

#        g.read(4)
#end new stuff
        print 'magic number is', numverts
        print 'meshcode = ', meshcode
        print 'meshcode location  = ', meshcodeaddress_str
        print 'file location equals', mslclocation

        print 'first group'
        type = '   Mesh '

        colon = ';'
        comma = ','
        endline = '\n'
        space = '   '
        three = '3;'
        startbracket = ' {'

#-----------------------Write Frame info needed for multiple objects

        frame1 = 'Frame '
        frame2 =  'FrameTransformMatrix {'
        frame3 = '1.000000, 0.000000, 0.000000, 0.000000,'
        frame4 = '0.000000, 1.000000, 0.000000, 0.000000,'
        frame5 = '0.000000, 0.000000, 1.000000, 0.000000,'
        frame6 = '0.000000, 0.000000, 0.000000, 1.000000;;'
        frame7 = '}'

        w.write(endline)
        w.write(frame1)
        w.write(meshname_for_file)
        w.write(startbracket)
        w.write(endline)
        w.write(frame2)
        w.write(endline)
        w.write(frame3)
        w.write(endline)
        w.write(frame4)
        w.write(endline)
        w.write(frame5)
        w.write(endline)
        w.write(frame6)
        w.write(endline)
        w.write(frame7)
        w.write(endline)
#----------------------check for mulitple bones
        for i in range (0,200):
            start_mesh_data = g.tell()
            back_4 = start_mesh_data - 4
            g.seek(back_4)
            checkalpha = g.read(4)
            isitallnum = checkalpha.isalnum()
            isitallnum_str = str(isitallnum)
            print 'is it allnum in loop?', isitallnum_str
            print 'check alpha = ', checkalpha

            if isitallnum_str == 'False':
                g.seek(start_mesh_data)
                break
            g.seek(start_mesh_data)
            back_8 = start_mesh_data - 8
            g.seek(back_8)
            bone_name_size = struct.unpack('<L', g.read(4))[0] 
            g.read(bone_name_size)
            g.read(4)
            numverts = struct.unpack('<L', g.read(4))[0]
            meshcodeaddress = g.tell()
            meshcode = struct.unpack('<L', g.read(4))[0]
            meshcode_str = str(meshcode)
            numverts_str = str(numverts)
            numvertsend = numverts - 1
#            g.read(4)            




#----------------------Start Getting Mesh Data



        w.write(type)
        w.write (meshname_for_file)
        w.write(startbracket)
        w.write(endline)






        w.write(space)
        w.write(numverts_str)
        w.write(colon)
        w.write(endline)
        for i in range (0,numverts):
            i_int = int(i)
            dat1 = struct.unpack('<f', g.read(4))[0] #code for 4-byte float
            dat2 = struct.unpack('<f', g.read(4))[0] #code for 4-byte float
            dat3 = struct.unpack('<f', g.read(4))[0] #code for 4-byte float
            dat3_plus_one = dat3 + 1
            char_dat1 = str(dat1)
            char_dat2 = str(dat2)
            char_dat3 = str(dat3_plus_one)

            if i_int != numvertsend:                
                dat3_end = char_dat3 + ';,\n'
            if i_int == numvertsend:                
                dat3_end = char_dat3 + ';;\n'



            print dat1, ',', dat2, ',', dat3, ';' 
            w.write(space)
            w.write(char_dat1)
            w.write(colon)
            w.write(char_dat2)
            w.write(colon)
            w.write(dat3_end)


#        w.write(insertfacenum_end)         
#new stuff for Space Marine whm
        print 'second group, probably vert colors'

#        type2 = '   vert colors? {'
#        typeend2 = type2 + '\n'

#        w.write(typeend2)
#        w.write(space)
#        w.write(numverts_str)
#        w.write(colon)
#        w.write(endline)


#--------------------------This data does not apply to buildings
#-------------if meshcode 39 then this type of data in mesh, probably vert colors, if meshcode = 37
#--------------this data not in mesh



        if meshcode_str == '39':   
            for i in range (0,numverts):
                i_int = int(i)
                dat1 = struct.unpack('<L', g.read(4))[0] #code for 4-byte float
                dat2 = struct.unpack('<L', g.read(4))[0] #code for 4-byte float
                dat2a = struct.unpack('<L', g.read(4))[0] #code for 4-byte float
                dat3 = struct.unpack('<L', g.read(4))[0] #code for 4-byte float
#            char_dat1 = str(dat1)
#            char_dat2 = str(dat2)
#            char_dat2a = str(dat2a)
#            char_dat3 = str(dat3)
#            if i_int != numvertsend:                
#                dat3_end = char_dat3 + ';,\n'
#            if i_int == numvertsend:                
#                dat3_end = char_dat3 + ';;\n'


#            print dat1, ',', dat2, ',', dat2a, ',', dat3, ';' 
#            w.write(space)
#            w.write(char_dat1)
#            w.write(colon)
#            w.write(char_dat2)
#            w.write(colon)
#            w.write(char_dat2a)
#            w.write(colon)
#            w.write(dat3_end)

#        w.write(insertfacenum_end)             

#end new stuff


#-------------------------------STart MeshNormals

        start_mesh_normals = g.tell()

        print 'second group, probably Mesh Normals'

        type2 = '   MeshNormals {'
        typeend2 = type2 + '\n'

#        w.write(typeend2)
#        w.write(space)
#        w.write(numverts_str)
#        w.write(colon)
#        w.write(endline)
   
        for i in range (0,numverts):
            i_int = int(i)
            dat1 = struct.unpack('<f', g.read(4))[0] #code for 4-byte float
            dat2 = struct.unpack('<f', g.read(4))[0] #code for 4-byte float
            dat3 = struct.unpack('<f', g.read(4))[0] #code for 4-byte float
            char_dat1 = str(dat1)
            char_dat2 = str(dat2)
            char_dat3 = str(dat3)
            if i_int != numvertsend:                
                dat3_end = char_dat3 + ';,\n'
            if i_int == numvertsend:                
                dat3_end = char_dat3 + ';;\n'


            print dat1, ',', dat2, ',', dat3, ';' 
#            w.write(space)
#            w.write(char_dat1)
#            w.write(colon)
#            w.write(char_dat2)
#            w.write(colon)
#            w.write(dat3_end)

#        w.write(insertfacenum_end)

        start_UV_coordinates = g.tell()             

        print '3rd group texture coordinates UV'
        type3 = '   MeshTextureCoords {'
        typeend3 = type3 + '\n'

        endbracket = '   }'
        endbracketend = endbracket + '\n'
#        w.write(endbracketend)
#        w.write(typeend3)

#        w.write(space)
#        w.write(numverts_str)
#        w.write(colon)
#        w.write(endline)

        for i in range (0,numverts):
            i_int = int(i)
            dat1 = struct.unpack('<f', g.read(4))[0] #code for 4-byte float
            dat2 = struct.unpack('<f', g.read(4))[0] #code for 4-byte float
            char_dat1 = str(dat1)
            char_dat2 = str(dat2)
            if i_int != numvertsend:                
                dat2_end = char_dat2 + ';,\n'
            if i_int == numvertsend:                
                dat2_end = char_dat2 + ';;\n'


            print dat1, ',', dat2, ';' 
#            w.write(space)
#            w.write(char_dat1)
#            w.write(colon)
#            w.write(dat2_end)
        g.read(5)
#        g.read(5)  - for unit models
        if whmconfirm == 'MSLC':
#            g.read(3)  for space marine use rgread below
            g.read(3)
        endlocation = g.tell()
        start_facenum = g.tell()
        print 'end of data for script at', endlocation
        materialsize = struct.unpack('<L', g.read(4))[0]
        print 'meshcode = ', meshcode
        print 'meshcodeaddress at', meshcodeaddress
        print 'start face numbers = ', start_facenum  
        print 'materialsize = ', materialsize
        g.read(materialsize)
        facenum = struct.unpack('<L', g.read(4))[0] 
        facediv = facenum/3
        facediv_str = str(facediv)
        facedivend = facediv-1
        print facenum
        print facediv

        type4 = 'Template numFaces, paste as indicated above then delete from end'
        typeend4 = type4 + '\n'

#        w.write(typeend4)

#        w.write(space)
#        w.write(facediv_str)
#        w.write(colon)
#        w.write(endline)


        for i in range (0,facediv):
            i_int = int(i)
            dat1 = struct.unpack('<h', g.read(2))[0] #code for 2-byte integer
            dat2 = struct.unpack('<h', g.read(2))[0] #code for 2-byte integer
            dat3 = struct.unpack('<h', g.read(2))[0] #code for 2-byte integer
            char_dat1 = str(dat1)
            char_dat2 = str(dat2)
            char_dat3 = str(dat3)
            if i_int != facedivend:                
                dat3_end = char_dat3 + ';,\n'
            if i_int == facedivend:                
                dat3_end = char_dat3 + ';;\n'



            print dat1, ',', dat2, ',', dat3, ';' 
#            w.write(space)
#            w.write(three)
#            w.write(char_dat1)
#            w.write(comma)
#            w.write(char_dat2)
#            w.write(comma)
#            w.write(dat3_end)
        endread = g.tell()


#////////////////////////Now go back and write data in correct order to make .x file///////////////////////////// 


#---------------------write facenumber data after mesh

        g.seek(start_facenum)
        print 'end of data for script at', endlocation
        materialsize = struct.unpack('<L', g.read(4))[0] 
        print 'meshcode = ', meshcode
        print materialsize
        g.read(materialsize)
        facenum = struct.unpack('<L', g.read(4))[0] 
        facediv = facenum/3
        facediv_str = str(facediv)
        facedivend = facediv-1
        print facenum
        print facediv

        type4 = 'Template numFaces, paste as indicated above then delete from end'
        typeend4 = type4 + '\n'

#        w.write(typeend4)

        w.write(space)
        w.write(facediv_str)
        w.write(colon)
        w.write(endline)


        for i in range (0,facediv):
            i_int = int(i)
            dat1 = struct.unpack('<h', g.read(2))[0] #code for 2-byte integer
            dat2 = struct.unpack('<h', g.read(2))[0] #code for 2-byte integer
            dat3 = struct.unpack('<h', g.read(2))[0] #code for 2-byte integer
            char_dat1 = str(dat1)
            char_dat2 = str(dat2)
            char_dat3 = str(dat3)
            if i_int != facedivend:                
                dat3_end = char_dat3 + ';,\n'
            if i_int == facedivend:                
                dat3_end = char_dat3 + ';;\n'



            print dat1, ',', dat2, ',', dat3, ';' 
            w.write(space)
            w.write(three)
            w.write(char_dat1)
            w.write(comma)
            w.write(char_dat2)
            w.write(comma)
            w.write(dat3_end)


#---------------------------- write meshnormal data

        g.seek(start_mesh_normals)

        print 'second group, probably Mesh Normals'

        type2 = '   MeshNormals {'
        typeend2 = type2 + '\n'

        w.write(typeend2)
        w.write(space)
        w.write(numverts_str)
        w.write(colon)
        w.write(endline)
   
        for i in range (0,numverts):
            i_int = int(i)
            dat1 = struct.unpack('<f', g.read(4))[0] #code for 4-byte float
            dat2 = struct.unpack('<f', g.read(4))[0] #code for 4-byte float
            dat3 = struct.unpack('<f', g.read(4))[0] #code for 4-byte float
            char_dat1 = str(dat1)
            char_dat2 = str(dat2)
            char_dat3 = str(dat3)
            if i_int != numvertsend:                
                dat3_end = char_dat3 + ';,\n'
            if i_int == numvertsend:                
                dat3_end = char_dat3 + ';;\n'


            print dat1, ',', dat2, ',', dat3, ';' 
            w.write(space)
            w.write(char_dat1)
            w.write(colon)
            w.write(char_dat2)
            w.write(colon)
            w.write(dat3_end)


#----------------------------write facenum data after meshnormals

        g.seek(start_facenum)
        print 'end of data for script at', endlocation
        materialsize = struct.unpack('<L', g.read(4))[0] 
        print materialsize
        g.read(materialsize)
        facenum = struct.unpack('<L', g.read(4))[0] 
        facediv = facenum/3
        facediv_str = str(facediv)
        facedivend = facediv-1
        print facenum
        print facediv

        type4 = 'Template numFaces, paste as indicated above then delete from end'
        typeend4 = type4 + '\n'

#        w.write(typeend4)

        w.write(space)
        w.write(facediv_str)
        w.write(colon)
        w.write(endline)


        for i in range (0,facediv):
            i_int = int(i)
            dat1 = struct.unpack('<h', g.read(2))[0] #code for 2-byte integer
            dat2 = struct.unpack('<h', g.read(2))[0] #code for 2-byte integer
            dat3 = struct.unpack('<h', g.read(2))[0] #code for 2-byte integer
            char_dat1 = str(dat1)
            char_dat2 = str(dat2)
            char_dat3 = str(dat3)
            if i_int != facedivend:                
                dat3_end = char_dat3 + ';,\n'
            if i_int == facedivend:                
                dat3_end = char_dat3 + ';;\n'



            print dat1, ',', dat2, ',', dat3, ';' 
            w.write(space)
            w.write(three)
            w.write(char_dat1)
            w.write(comma)
            w.write(char_dat2)
            w.write(comma)
            w.write(dat3_end)

#--------------------------- write UV data

        g.seek(start_UV_coordinates)             

        print '3rd group texture coordinates UV'
        type3 = '   MeshTextureCoords {'
        typeend3 = type3 + '\n'

        endbracket = '   }'
        endbracketend = endbracket + '\n'
        w.write(endbracketend)
        w.write(typeend3)

        w.write(space)
        w.write(numverts_str)
        w.write(colon)
        w.write(endline)

        for i in range (0,numverts):
            i_int = int(i)
            dat1 = struct.unpack('<f', g.read(4))[0] #code for 4-byte float
            dat2 = struct.unpack('<f', g.read(4))[0] #code for 4-byte float
            char_dat1 = str(dat1)
            char_dat2 = str(dat2)
            if i_int != numvertsend:                
                dat2_end = char_dat2 + ';,\n'
            if i_int == numvertsend:                
                dat2_end = char_dat2 + ';;\n'


            print dat1, ',', dat2, ';' 
            w.write(space)
            w.write(char_dat1)
            w.write(colon)
            w.write(dat2_end)


#----------write brackets at end of object and start new object


        meshendbracket = '    }'
        objectendbracket = '}'
        w.write(endbracketend)
        w.write(meshendbracket)
        w.write(endline)
        w.write(objectendbracket)
#        w.write(endline)
        
        end_uv = g.tell()



#//////////////now close files and stop

#        g.seek(endread)
#        g.read(20)
        g.seek(oldchunk_start)
        nextchunk = oldchunk_start + oldchunk_size
        g.seek(nextchunk)
#        nextchunk = g.tell()
        next4 = g.read(4)
        print 'end of read at', endread
        print 'end of UVs at', end_uv
        print 'next chunk is at', nextchunk
        print 'next 4 bytes', next4
        print 'i loop', i
        print 'is it allnum?', isitallnum_str
        print 'This MSLC started at', oldchunk_start
        print 'the chunk size is',    oldchunk_size

#        break

    g.seek(nextchunk)