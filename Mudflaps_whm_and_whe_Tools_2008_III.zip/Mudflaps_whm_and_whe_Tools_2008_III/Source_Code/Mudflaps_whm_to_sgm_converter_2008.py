#Script to convert whm to sgm files
# for Dawn of War Object Editor

#Line 977 is the part where the end of BANM is found.  Its where the problem is

import struct
import marshal
import string 
import tkFileDialog


import Tkinter

from Tkconstants import *
Hint = Tkinter.Tk()
frame = Tkinter.Frame(Hint, relief=RIDGE, borderwidth=2)
frame.pack(fill=BOTH,expand=1)
label = Tkinter.Label(frame, text="OPEN Hint \n This tool can open .whms for troops models in the data/art/ebps path")
label2 = Tkinter.Label(frame, text="File Use \n Save the converted file as a .sgm file in the Datageneric directory for your mod then open it in the Object Editor.")
label.pack(fill=X, expand=1)
label2.pack(fill=X, expand=1)
button = Tkinter.Button(frame,text="Close Hints",command=Hint.destroy)
button.pack(side=BOTTOM)

first_mesh_low = 1
two = 2
two_int = int(two)
#end_canm_write_data = 1
 

filetoparse = tkFileDialog.askopenfilename(filetypes=[("whm", "whm")], title = 'Choose a .whm file to convert to .sgm format')


 

filetowrite = tkFileDialog.asksaveasfilename(filetypes=[("sgm", "sgm")], title = 'Save exported .sgm file as.....', defaultextension = ".sgm")


shdr_tex_list = ['art']
art_check_yes = 0

w = open(filetowrite,'wb')

g = open(filetoparse,'rb')
s = open('bonelist.dat','wb')
relic_header = g.read(24)
w.write(relic_header) 
g.read()
endoffile = g.tell() - 20
endoffile_int = int(endoffile)
g.seek(18)
space = g.read(1)      #This make a 00 variable that is written after bone and marker names be careful that all whms have 00 at this address.
g.seek(28)

burnfile = g.read(4)
ver_loc = g.tell()
ver_read = g.read(4)
g.seek(ver_loc)
ver_read3 = g.read(3)
burnfile_str = str(burnfile)
print burnfile_str

zero = 0
zero_int = int(zero)
zero_longint = struct.pack('<i', zero_int)
z = open('write_float.dat', 'wb')
marshal.dump(zero_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
zero_int_again = y.read(4)

mesh_list_str = 'mesh'




import struct
import marshal
import string

#----------------------------------make a string list of mesh names for checking against in animations

for i in range(1,endoffile_int):

    mslc_search_position = g.tell()
    search = g.read(1)
    if search == 'M' or search == 'm':
        g.seek(mslc_search_position)
        ismslc = g.read(4)
        if ismslc == 'MSLC' or ismslc == 'mslc':
            g.read(8)
            checknamesize = struct.unpack('<L', g.read(4))[0] 
            name = g.read(checknamesize)
            mesh_list_str = mesh_list_str + name
            first_mesh_position = g.tell()
            first_mesh = g.read(3)
            first_mesh_low = string.lower(first_mesh)
            g.seek(first_mesh_position)
            first_mesh_initial = g.read(1)
#            break


#----------------variable for counting mslcs

countmesh = 0


g.seek(24)                  #This part puts the file in the right position if there is no Burn info
if burnfile_str == 'FBIF':  #this part puts the file in right position if it has Burn Info in front If you change this make sure you change checksize_int at the end.
    g.seek(36)               
    checkFBIFsize = struct.unpack('<L', g.read(4))[0]
    checkFBIFsize_int = int(checkFBIFsize)
    burnfile_data_end = 57 + checkFBIFsize_int
    g.seek(burnfile_data_end)


#------------<<<<<<<<<<<<<<<<<Start Main Loop Here>>>>>>>>>>>>>>>>>>>>>>---------------------

for i in range(1,1000): 
    checkposition = g.tell()
    checktype = g.read(4) 
    checkID = g.read(4)
    ver_loc = g.tell()
    print 'ver_loc = ', ver_loc
    checkver = struct.unpack('<L', g.read(4))[0] 
    checksize = struct.unpack('<L', g.read(4))[0]
    namesize_loc = g.tell()
    namesize_read = g.read(4)
    g.seek(namesize_loc) 
    checknamesize = struct.unpack('<L', g.read(4))[0] 
    noname_position = g.tell()
    name_3_long = g.read(3)
    g.seek(noname_position)
    name = g.read(checknamesize)
    position = g.tell()
    header_dif = position-checkposition
    header_dif_int = int(header_dif)
    oldchunk_start = g.tell()
    oldchunk_size = checksize
        
    if checknamesize == '0000':
        nextchunk = noname_position + checksize
    if checknamesize != '0000':
        nextchunk = position + checksize 
    if checktype == 'FOLD':
        if checknamesize == '0000':
            nextchunk = noname_position
        if checknamesize != '0000':
            nextchunk = position 
 
    print checkposition 
    print checktype
    print checkID
    print checkver
    print checksize
    print checknamesize
    print nextchunk

#-------------------------------------Loop Breaking Here

    if nextchunk > endoffile:
        Hint.mainloop()
        break
#    if checkID == 'SHDR':
        w.close()
        Hint.mainloop()
        endofloop = g.tell()
        print 'ended at folder ANIM at byte', endofloop        
        break
#-------------------------------------End Loop Breaking



    if checkID == 'RSGM':
        g.seek(checkposition)
        rsgm_ver = ver_read
        rsgm_ver_loc = ver_loc
#        print 'header_dif_int = ', header_dif_int
        RSGM_header = g.read(header_dif_int)
        rsgm_write_start = w.tell()
        rsgm_write_ver_loc = rsgm_write_start + 8
        w.write(RSGM_header)
        start_rsgm_chunk = w.tell()
        print 'RSGM header printed'

    if checkID == 'SHDR':
        name_str = str(name_3_long)
        shdr_tex_list.append(name_str)

#SSHR version needs to be 1

    if checkID == 'SSHR':
        g.seek(checkposition)
#        print 'header_dif_int = ', header_dif_int
        SSHR_header = g.read(header_dif_int)
        sshr_write_start = w.tell()
        w.write(SSHR_header)
        print 'SSHR header printed'
        checksize_int = int(checksize)
        print 'size checksize_int is ', checksize_int 
        SSHR_data = g.read(checksize_int)
        w.write(SSHR_data)
        end_sshr_data = w.tell()

        w.seek(sshr_write_start)
        one = 1
        one_int = int(one)
        w.write(checktype)
        w.write(ver_read3)
        marshal.dump(one, w)
        w.seek(sshr_write_start)
        w.write(checktype)
        w.write(checkID)
        w.seek(end_sshr_data)



    if checkID == 'SKEL':
        g.seek(checkposition)
        skel_start = g.tell()        
        skel_ver = ver_read
        skel_ver_loc = ver_loc
        fold = 'FOLD'
        info = 'INFO'
        bone = 'BONE'
        skel = 'SKEL'

#skel folder
        skel_header = g.read(header_dif_int)
        skel_start_write = w.tell()
        write_skel_ver_loc = skel_start_write + 8
        w.write(skel_header)
        start_skel_chunk = w.tell()
        w.seek(skel_start_write)
        w.write(fold)
        w.seek(start_skel_chunk)

#info chunk
        w.write(checktype)
        w.write(info)
        info_ver_loc = w.tell()
        w.write(ver_read3)
        four = 4
        four_int = int(four)
        marshal.dump(four_int,w) #chunksize
        info_namesize_loc = w.tell()
        w.seek(info_ver_loc)
        w.write(ver_read)
        w.seek(info_namesize_loc)
        w.write(namesize_read)
        g_loc = g.tell()
        bonetotal_read = g.read(4)
        g.seek(g_loc)
        checkbonetotal = struct.unpack('<L', g.read(4))[0]
        checkbonetotal_int = int(checkbonetotal)
        w.write(bonetotal_read)

        for k in range(0,checkbonetotal_int):
            g_loc = g.tell()            
            checkbonenamesize = struct.unpack('<L', g.read(4))[0]
            bonename_start = g.tell()
            bonename_3_byte = g.read(3)
            s.write(bonename_3_byte)
            g.seek(bonename_start)
            bonename = g.read(checkbonenamesize)
            bone_data = g.read(32)

            bone_data_write_start = w.tell()
            w.write(checktype)
            w.write(bone)
            w_loc = w.tell()

#correction here for space after name convention in .sgm files
            w.write(ver_read3)
            w.write(ver_read)
            correct_bone_name_size = checkbonenamesize + 1
            correct_bone_name_size_int = int(correct_bone_name_size)
            marshal.dump(correct_bone_name_size_int, w)
            w.write(bonename)
            w.write(space)
            w_namesize_loc = w.tell()
            w.seek(w_loc)
            w.write(ver_read3)

            bone_data_size = 32
            bone_data_size_int = int(bone_data_size)
            marshal.dump(bone_data_size_int,w)            # this chunksize needs to be longint later
            w.seek(w_loc)
            w.write(ver_read)
#---------------Bone version needs to be 5

            w.seek(bone_data_write_start)
            w.write(checktype)
            w.write(ver_read3)
            five = 5
            five_int = int(five)
            marshal.dump(five_int, w)
            w.seek(bone_data_write_start)
            w.write(checktype)
            w.write(bone)

#---------------back to writing bone data
            w.seek(w_namesize_loc)
            w.write(bone_data)
        nextchunk = g.tell()
        s.close()
        sr = open('bonelist.dat','rb')
        
#Skel chunksize write        
        end_skel_chunk = w.tell()
        skel_chunksize = end_skel_chunk - start_skel_chunk
        skel_chunksize_int = int(skel_chunksize)
        w.seek(write_skel_ver_loc)
        w.write(ver_read3)
        marshal.dump(skel_chunksize_int, w)

        print 'Start SKEL Chunk', start_skel_chunk
        print 'end SKEL chunk', end_skel_chunk
        print 'skel_chunksize_int', skel_chunksize_int
        print 'write_skel_ver_loc', write_skel_ver_loc

#-------------------SKEL Version needs to be 3
        w.seek(write_skel_ver_loc)
        w.write(ver_read)
        w.seek(skel_start_write)
        w.write(fold)
        w.write(ver_read3)
        three = 3
        three_int = int(three)
        marshal.dump(three_int, w)
        w.seek(skel_start_write)
        w.write(fold)
        w.write(skel)
        
        w.seek(end_skel_chunk)                




#---------------Write MSGR 
            
    if checkID == 'MSGR':
        g.seek(checkposition)
        msgr_checkposition = g.tell()

        msgr_ver = ver_read
        msgr_ver_loc = ver_loc
        print 'msgr header_dif_int = ', header_dif_int
        msgr_header = g.read(header_dif_int)
        msgr_write_start = w.tell()
        msgr_write_ver_loc = msgr_write_start + 8
        w.write(msgr_header)
        start_msgr_chunk = w.tell()
        print 'MSGR header printed'
        nextchunk = g.tell()
        checkifmsgrdata = g.read(4)
        if checkifmsgrdata =='DATA':
            first_mesh_position = g.tell()
            g.read(24)
            first_mesh = g.read(4)
            print 'first_mesh_msgr = ', first_mesh
            first_mesh_low = string.lower(first_mesh)
        g.seek(nextchunk)        



#--------------Count meshes

        for i in range(1,500): 
            countcheckposition = g.tell()
            countchecktype = g.read(4)
            if countchecktype == 'DATA':
#                nextchunk = countcheckposition
                break
 
            countcheckID = g.read(4)
            g.read(4)
            countchecksize = struct.unpack('<L', g.read(4))[0]
            countchecknamesize = struct.unpack('<L', g.read(4))[0] 
            name = g.read(countchecknamesize)

            countmesh = countmesh + 1






#----------------write MSLC header      


    if checkID == 'MSLC':
        g.seek(checkposition)
        mslc_ver = ver_read
        mslc_ver_loc = ver_loc
        print 'header_dif_int = ', header_dif_int
        mslc_header = g.read(header_dif_int)
        mslc_write_start = w.tell()
        mslc_write_ver_loc = mslc_write_start + 8
        w.write(mslc_header)
        start_mslc_chunk = w.tell()
        print 'MSLC header printed'
        whmconfirm = 'MSLC'

#-------------------read/write DATA/DATA in MSLC

        g.seek(nextchunk)    
        checkposition = g.tell() 
        checktype = g.read(4) 
        checkID = g.read(4)
        checkver = struct.unpack('<L', g.read(4))[0] 
        checksize = struct.unpack('<L', g.read(4))[0] 
        checknamesize = struct.unpack('<L', g.read(4))[0] 
        noname_position = g.tell()
        name = g.read(checknamesize)

        position = g.tell()
        header_dif = position-checkposition
        header_dif_int = int(header_dif)
        g.seek(checkposition)
        mslc_data_header = g.read(header_dif_int)
        mslc_data_data_start = w.tell()
       
        mslc_data_data_ver_loc = mslc_data_data_start + 8

        w.write(mslc_data_header)
        start_mslc_data_data_chunk = w.tell()


        if checknamesize == '0000':
            nextchunk = noname_position
        if checknamesize != '0000':
            nextchunk = position 
        print 'file located at', nextchunk

#---------------------------------This will be the position to start reading DATA/DATA data
        g.seek(nextchunk)

#---------------------------------------------------------------------------------------



        if whmconfirm == 'MSLC':
            g.read(13)       #if the thing is reading DATADATA then this will jump to number of bones
        mslc_bone_number_location = g.tell()
        number_of_bones = struct.unpack('<L', g.read(4))[0]
        number_of_bones_int = int(number_of_bones)

#----------------------check for mulitple bones and find end of bone list
        for i in range (0,number_of_bones_int):
            g.read(8)
            start_mesh_data = g.tell()
            back_4 = start_mesh_data - 4
            g.seek(back_4)
            checkalpha = g.read(3)
            checkalpha = string.replace(checkalpha, '_', '')
            g.read(1)
            isitallnum = checkalpha.isalnum()
            isitallnum_str = str(isitallnum)
            print 'is it allnum in loop?', isitallnum_str
            print 'check alpha = ', checkalpha

            if isitallnum_str == 'False':
                g.seek(start_mesh_data)
                break
            g.seek(start_mesh_data)
            back_8 = start_mesh_data - 8
            g.seek(back_8)
            bone_name_size = struct.unpack('<L', g.read(4))[0] 
            track_bone_name = g.read(bone_name_size)
            print 'read', track_bone_name
            g.read(4)



        numverts = struct.unpack('<L', g.read(4))[0]
        print 'numverts = ', numverts
        meshcodeaddress = g.tell()
        print 'meshcodeaddress = ', meshcodeaddress
        meshcode = struct.unpack('<L', g.read(4))[0]
        meshcode_str = str(meshcode)
        numverts_str = str(numverts)
        numvertsend = numverts - 1


#-------------Now that bones are sorted out, read/write the bone data that precedes mesh data
        end_bone_list = g.tell()
        bone_list_size = end_bone_list - nextchunk
        g.seek(nextchunk)
        bone_list_data = g.read(bone_list_size)
        w.write(bone_list_data)
        start_mesh_data = g.tell()




#----------------------Start Getting Mesh Data ------This code should strip out the extra 20 bytes of data in the sgm export




#---------------------------------start searching for materialname
        for i in range(1,endoffile_int):

            search_position = g.tell()
            search = g.read(1)
            search_alnum = search.isalnum()
            search_alnum_str = str(search_alnum)
            art_check_yes = 0
            if search_alnum_str == 'True':
                g.seek(search_position)
                ismaterialname = g.read(3)
                material_alnum = ismaterialname.isalnum()
                material_alnum_str = str(material_alnum)

#---have a check against a list with 'art' and all the internal SHDR names in it.

                for p in range(0,int(len(shdr_tex_list))):
                    p_int = int(p)
                    check_art = str(shdr_tex_list[p_int])
                    if ismaterialname == check_art:
                        art_check_yes = 1           


                if material_alnum_str == 'True' and art_check_yes == 1:
#                    print 'ismaterialname = ', ismaterialname

#----------------this part checks if Material namesize makes sense since in some cases random code can be 3 bytes of alphanumeric data
                    material_namesize_test_loc = search_position - 4
                    g.seek(material_namesize_test_loc)
                    material_namesize_test = struct.unpack('<L', g.read(4))[0]
                    material_namesize_test_str = str(material_namesize_test)
                    endoffile_int_str = str(endoffile_int)
                    if len(material_namesize_test_str) < len(endoffile_int_str):
                        start_mat = search_position
                        mesh_chunksize = start_mat - start_mesh_data

#-----------------minus 12 or minus 8 will depend on the file, if choose 8 to get chaos lord to work make g.read below 4
                        mesh_chunksize_minus = mesh_chunksize - 12
                        break


# This bit here keeps the loop going if g.read3 fails

                g.seek(search_position)
                g.read(1)



        g.seek(start_mesh_data)
        numverts_data = g.read(mesh_chunksize_minus)
        w.write(numverts_data)


#-------this skipping 4 bytes business does not apply to all
        g.read(4) #skipping 4 bytes of zeros in whms buut not in sgms
        material_head_start = g.tell()
        material_head = g.read(4)
        w.write(material_head)
        g.seek(material_head_start)
        print 'material number start = ', material_head_start

#---------this is the number of materials

        number_of_materials = int(struct.unpack('<L', g.read(4))[0])
        print 'number of materials = ', number_of_materials 




        for m in range(0, number_of_materials):
            m_int = int(m)
#        g.seek(material_namesize_test_loc)
            material_namesize_loc = g.tell()        
            material_namesize = struct.unpack('<L', g.read(4))[0]
            g.seek(material_namesize_loc)
            material_namesize_for_write = g.read(4)
            w.write(material_namesize_for_write)
            print 'material name size at ', material_namesize_loc
            material_name = g.read(material_namesize)
            w.write(material_name)


            facenum_head_start = g.tell()
            facenum_size = int(struct.unpack('<L', g.read(4))[0])

#--------------Go back and get all the facenum data, size (4 bytes) and mystery 4 bytes at end
            g.seek(facenum_head_start)
            facenum_data_size = (facenum_size * 2) + 8

#----------if it is the last material then put 4 mystery zeros at the end followed by 12 bytes of shadow data
#            if m_int == number_of_materials:
#                facenum_data_size = (facenum_size * 2) + 8 + 4 + 12 

#---------------need to add code here for 12 bytes of shadow data


            facenum_data = g.read(facenum_data_size)
            if m_int != (number_of_materials - 1):
                g.read(4)
            w.write(facenum_data)

#----------- Now add 16 zeros for end of facenum data and no shadow data
            if m_int == int(number_of_materials - 1):

                w.write(zero_int_again)
                w.write(zero_int_again)
                w.write(zero_int_again)
                w.write(zero_int_again)


        print 'start looking for bvol'



#---------------------------------start searching for BVOL
        for i in range(1,100000):

            search_position = g.tell()
            search = g.read(1)
            search_alnum = search.isalnum()
            search_alnum_str = str(search_alnum)
            if search_alnum_str == 'True':
                g.seek(search_position)
                isbvol = g.read(8)
                if isbvol == 'DATABVOL':
                    print 'found bvol start'
                    start_bvol = search_position
                    end_mslc_data_chunksize = start_bvol - facenum_head_start
                    end_mslc_data_chunksize_minus = end_mslc_data_chunksize - 16
                    break
                    
                g.seek(search_position)
                g.read(1)

        g.seek(start_bvol)
#        facenum_data = g.read(end_mslc_data_chunksize_minus)
#        w.write(facenum_data)
        end_mslc_data_chunk = w.tell()


#        g.read(16)     # skip 16 bytes of zeros in whms but not sgms

#------------------now write bvol data in MSLC

        start_mslc_bvol = g.tell()
        print 'start_mslc_bvol = ', start_mslc_bvol
        mslc_bvol_header = g.read(20)
        w.write(mslc_bvol_header)
        g.seek(start_mslc_bvol)
        g.read(12)
        mslc_bvol_size = struct.unpack('<L', g.read(4))[0]
        g.read(4)
        mslc_bvol_data = g.read(mslc_bvol_size)
        w.write(mslc_bvol_data)
        end_mslc_bvol_chunk = w.tell()

        nextchunk = g.tell()


#--------------------------------now fix chunk sizes in MSGR, MSLC, and MSLC DATA/DATA

#---------------write new chunksize to MSLC DATA/DATA header


        
        mslc_datadata_chunksize = end_mslc_data_chunk - start_mslc_data_data_chunk
        mslc_datadata_chunksize_int = int(mslc_datadata_chunksize)
        w.seek(mslc_data_data_ver_loc)
        w.write(ver_read3)
        marshal.dump(mslc_datadata_chunksize_int, w)
        w.seek(mslc_data_data_ver_loc)
        w.write(ver_read)

#---------------MSLC DATA DATA needs to be version 2
        w.seek(mslc_data_data_start)
        data = 'DATA'
        w.write(data)
        w.write(ver_read3)
        two = 2
        two_int = int(two)
        marshal.dump(two_int, w)
        w.seek(mslc_data_data_start)
        w.write(data)
        w.write(data)




        w.seek(end_mslc_bvol_chunk) 


#-------------write new chunksize to MSLC header


        
        mslc_chunksize = end_mslc_bvol_chunk - start_mslc_chunk
        mslc_chunksize_int = int(mslc_chunksize)
        w.seek(mslc_write_ver_loc)
        w.write(ver_read3)
        marshal.dump(mslc_chunksize_int, w)
        w.seek(mslc_write_ver_loc)
        w.write(ver_read)
        w.seek(end_mslc_bvol_chunk) 



#------------------read/write MSGR DATA/DATA and bvol, if there.

        g.seek(nextchunk)        
        g.read(4)
        check_for_msgr_data = g.read(4)
        check_for_msgr_data_str = str(check_for_msgr_data)
        if check_for_msgr_data_str == 'DATA':
            g.read(4)
            msgr_data_data_chunksize = struct.unpack('<L', g.read(4))[0]
            msgr_data_data_chunksize_int = int(msgr_data_data_chunksize)
            g.seek(nextchunk)
            msgr_data_data_header = g.read(20)
            msgr_data_data = g.read(msgr_data_data_chunksize_int)
            w.write(msgr_data_data_header)
            w.write(msgr_data_data)
            end_msgr_data_data = g.tell()
            g.read(12)
            msgr_bvol_chunksize = struct.unpack('<L', g.read(4))[0]
            msgr_bvol_chunksize_int = int(msgr_bvol_chunksize)
            g.seek(end_msgr_data_data)
            msgr_bvol_header = g.read(20)
            msgr_bvol = g.read(msgr_bvol_chunksize_int)
            w.write(msgr_bvol_header)
            w.write(msgr_bvol)
            end_msgr_bvol_data = w.tell()
            nextchunk = g.tell()
            
            




#-------------write new chunksize to MSGR header


        
            msgr_chunksize = end_msgr_bvol_data - start_msgr_chunk
            msgr_chunksize_int = int(msgr_chunksize)
            w.seek(msgr_write_ver_loc)
            w.write(ver_read3)
            marshal.dump(msgr_chunksize_int, w)
            w.seek(msgr_write_ver_loc)
            w.write(ver_read)
            w.seek(end_msgr_bvol_data) 


#------------here is where the rsgm fix starts

        
            rsgm_chunksize = end_msgr_bvol_data - start_rsgm_chunk
            rsgm_chunksize_int = int(rsgm_chunksize)
            w.seek(rsgm_write_ver_loc)
            w.write(ver_read3)
            marshal.dump(rsgm_chunksize_int, w)
            w.seek(rsgm_write_ver_loc)
            w.write(ver_read)
            w.seek(end_msgr_bvol_data) 
        






#------------------read/write MSGR DATA/DATA and bvol, if there.
    if checkID == 'MSGR':
        g.seek(nextchunk)        
        g.read(4)
        check_for_msgr_data = g.read(4)
        check_for_msgr_data_str = str(check_for_msgr_data)
        msgr_check = g.tell()
        g.seek(nextchunk)
        if check_for_msgr_data_str == 'DATA':
            g.seek(msgr_check)
            g.read(4)
            msgr_data_data_chunksize = struct.unpack('<L', g.read(4))[0]
            msgr_data_data_chunksize_int = int(msgr_data_data_chunksize)
            g.seek(nextchunk)
            msgr_data_data_header = g.read(20)
            msgr_data_data = g.read(msgr_data_data_chunksize_int)
            w.write(msgr_data_data_header)
            w.write(msgr_data_data)
            end_msgr_data_data = g.tell()
            g.read(12)
            msgr_bvol_chunksize = struct.unpack('<L', g.read(4))[0]
            msgr_bvol_chunksize_int = int(msgr_bvol_chunksize)
            g.seek(end_msgr_data_data)
            msgr_bvol_header = g.read(20)
            msgr_bvol = g.read(msgr_bvol_chunksize_int)
            w.write(msgr_bvol_header)
            w.write(msgr_bvol)
            end_msgr_bvol_data = w.tell()
            nextchunk = g.tell()
            
            





#-------------write new chunksize to MSGR header


        
            msgr_chunksize = end_msgr_bvol_data - start_msgr_chunk
            msgr_chunksize_int = int(msgr_chunksize)
            w.seek(msgr_write_ver_loc)
            w.write(ver_read3)
            marshal.dump(msgr_chunksize_int, w)
            w.seek(msgr_write_ver_loc)
            w.write(ver_read)
            w.seek(end_msgr_bvol_data) 



                
        
# split up MARK just like final SKEL, 48 bytes plusparent name and 4-byte parent namelength

    if checkID == 'MARK':
        g.seek(checkposition)
        g.read(header_dif_int)
        data = 'DATA'        
        checkmarktotal = struct.unpack('<L', g.read(4))[0]
        checkmarktotal_int = int(checkmarktotal)

        for k in range(0,checkmarktotal_int):
            k_name_loc = g.tell()
            checkmarknamesize = struct.unpack('<L', g.read(4))[0]
            g.seek(k_name_loc)
            mark_namesize = g.read(4)
            markname = g.read(checkmarknamesize)
            parent_loc = g.tell()
            parentsize = struct.unpack('<L', g.read(4))[0]
            parentsize_int = int(parentsize)
            parent_name = g.read(parentsize)
            g.seek(parent_loc)
            mark_chunksize = 52 + parentsize_int
            mark_chunksize_int = int(mark_chunksize)
            mark_data = g.read(mark_chunksize_int)
#            print 'Marker name', markname
            print 'marker chunksize', mark_chunksize_int
            w.write(data)
            w.write(checkID)
            w_loc = w.tell()           

#correction here for space after name convention in .sgm files
            w.write(ver_read3)
            w.write(ver_read)
            correct_mark_name_size = checkmarknamesize + 1
            correct_mark_name_size_int = int(correct_mark_name_size)
            marshal.dump(correct_mark_name_size_int, w)
            w.write(markname)
            w.write(space)
            w_chunk_loc = w.tell()
            w.seek(w_loc)



            w.write(ver_read3)
            marshal.dump(mark_chunksize_int,w)
            w.seek(w_loc)
            w.write(ver_read)
            w.seek(w_chunk_loc)
            w.write(mark_data)
        nextchunk = g.tell()

#write new chunksize to RSGM


        
#        end_skel_chunk = w.tell()
#        skel_chunksize = end_skel_chunk - start_rsgm_chunk
#        skel_chunksize_int = int(skel_chunksize)
#        w.seek(rsgm_write_ver_loc)
#        w.write(ver_read3)
#        marshal.dump(skel_chunksize_int, w)
#        w.seek(rsgm_write_ver_loc)
#        w.write(ver_read)
#        w.seek(end_skel_chunk) 


# split up CAMS just like final MARK, 48 bytes and 4-byte parent namelength
    if checkID == 'CAMS':
        cmra = 'CMRA'
        g.seek(checkposition)
        g.read(header_dif_int)
        checkmarktotal = struct.unpack('<L', g.read(4))[0]
        checkmarktotal_int = int(checkmarktotal)

        for k in range(0,checkmarktotal_int):
            k_name_loc = g.tell()
            checkmarknamesize = struct.unpack('<L', g.read(4))[0]
            g.seek(k_name_loc)
            mark_namesize = g.read(4)
            markname = g.read(checkmarknamesize)
            mark_data = g.read(52)
            mark_chunksize = 52
            mark_chunksize_int = int(mark_chunksize)
            w.write(data)
            w.write(cmra)
            w_loc = w.tell()  


#correction here for space after name convention in .sgm files
            w.write(ver_read3)
            w.write(ver_read)
            correct_cam_name_size = checkmarknamesize + 1
            correct_cam_name_size_int = int(correct_cam_name_size)
            marshal.dump(correct_cam_name_size_int, w)
            w.write(markname)
            w.write(space)
            w_chunk_loc = w.tell()
            w.seek(w_loc)



         
            w.write(ver_read3)
            marshal.dump(mark_chunksize_int,w)
            w.seek(w_loc)
            w.write(ver_read)
            w.seek(w_chunk_loc)
            w.write(mark_data)
        nextchunk = g.tell()





# Figure out ANIM, use SKEL as example since it needs an INFO chunk

        
    if checkID == 'ANIM':
        g.seek(checkposition)
        g.read(header_dif_int)
        fold = 'FOLD'
        info = 'INFO'
        bone = 'BONE'


#-------------Write anim folder
        start_write_anim_fold = w.tell()
        w.write(fold)
        w.write(checkID)
        anim_fold_ver_loc = w.tell()
        w.write(ver_read)
        anim_fold_chunksize_loc = w.tell()
        w.write(ver_read)
        w.write(namesize_read)  #namesize reads needs to be here
        w.write(name)
        start_anim_fold_chunk = w.tell()

#-------------write Data Chunk
        w.write(fold)
        w.write(data)
        anim_data_ver_loc = w.tell()
        w.write(ver_read)
        anim_data_chunksize_loc = w.tell()
        w.write(ver_read)
        w.write(namesize_read)  #namesize chunk here
        g.read(16)
        g.read(checknamesize)
        w.write(name)
        start_anim_data_chunk = w.tell()

#--------------write INFO info        

        anim_loc = g.tell()
        g.read(4)
        anim_info = g.read(8)


        w.write(data)
        w.write(info)
        anim_info_ver_loc = w.tell()
        w.write(ver_read)
        w.write(ver_read3)
        marshal.dump(zero_int, w)
        start_info_info = w.tell()
        
        w.seek(anim_info_ver_loc )
        w.write(ver_read3)
        eight = 8
        eight_int = int(eight)
        marshal.dump(eight_int,w)



#------------Info chunk needs to be version 5
        w.seek(start_anim_data_chunk)
        w.write(data)
        w.write(ver_read3)
        marshal.dump(five_int, w)
        w.seek(start_anim_data_chunk)
        w.write(data)
        w.write(info)


        w.seek(start_info_info)
        w.write(anim_info)  #need 8 bytes of info here. I think its first 8 bytes of Anim/Data


#-----------------write BANM chunks

        checkbanmgtotal_location = g.tell()
        print 'location of banm total = ', checkbanmgtotal_location 
        checkbanmtotal = struct.unpack('<L', g.read(4))[0]
        checkbanmtotal_int = int(checkbanmtotal)
        print 'check banm total = ', checkbanmtotal_int
        print 'checkbonetotal_int = ', checkbonetotal_int
        banm = 'BANM'
        countbones = 0
        countbones_int = 0
        endbone_data = 0



        for k in range(0,checkbanmtotal_int):
            print '------------START Bone Data Now in BANM--------'
            countbones = int(countbones + 1)
            countbones_int = int(countbones)
            print 'countbones in loop = ', countbones_int
            print 'check_banm_total_int =', checkbanmtotal_int
            banm_namesize_start = g.tell()
            checkbanmnamesize = struct.unpack('<L', g.read(4))[0]
            g.seek(banm_namesize_start)
            banm_namesize_read = g.read(4)
            bonename = g.read(checkbanmnamesize)
            print 'banm', bonename
            print 'banm location =', banm_namesize_start
            banm_data_start_write = w.tell()
            w.write(data)
            w.write(banm)
            banm_ver_loc = w.tell()


#correction here for space after name convention in .sgm files
            w.write(ver_read3)
            w.write(ver_read)
            correct_banm_name_size = checkbanmnamesize + 1
            correct_banm_name_size_int = int(correct_banm_name_size)
            marshal.dump(correct_banm_name_size_int, w)
            w.write(bonename)
            w.write(space)


#Now we have to search for end of Bone data
            start_bone_data = g.tell()

            for i in range(1,endoffile_int):

                search_position = g.tell()
                search = g.read(1)
                search_alnum = search.isalnum()
                search_alnum_str = str(search_alnum)
                if search_alnum_str == 'True':
                    sr.seek(0)
                    g.seek(search_position)
                    isbone = g.read(3)
                    isbone_str = str(isbone)
                    test_meshname = int(mesh_list_str.find(isbone_str))
#                    print 'isbone = ', isbone
#                    print 'first_mesh = ', first_mesh
#                    print 'first_mesh_low = ', first_mesh_low
                    g.seek(search_position)
                    g.read(1)
                    for s in range(0,checkbonetotal_int):
                        if countbones_int == checkbanmtotal_int:
                            if test_meshname != -1:
                                endbone_data = search_position
                                print 'end bone data in first mesh loop',endbone_data 
                                start_bip_namesize = search_position - 8
                                start_canm_namesize = search_position - 4
                                keep_banm_place = g.tell()
#----------------this part checks if CANM namesize makes sense since in some cases random code can be 3 bytes of alphanumeric data
                                g.seek(start_canm_namesize)
                                canm_namesize_test = struct.unpack('<L', g.read(4))[0]
                                canm_namesize_test_str = str(canm_namesize_test)
                                endoffile_int_str = str(endoffile_int)
                                g.seek(keep_banm_place)
                                if len(canm_namesize_test_str) < len(endoffile_int_str):
                                    endbone_data = search_position                                
                                    break


                        bone_list_check = sr.read(3)
                        if bone_list_check == isbone:
                            endbone_data = search_position
                            print 'end bone data in loop',endbone_data 
                            start_bip_namesize = search_position - 4
                            start_canm_namesize = search_position - 4
                            keep_banm_place = g.tell()
#----------------this part checks if CANM namesize makes sense since in some cases random code can be 3 bytes of alphanumeric data
                            g.seek(start_canm_namesize)
                            canm_namesize_test = struct.unpack('<L', g.read(4))[0]

                            canm_namesize_test_str = str(canm_namesize_test)
                            endoffile_int_str = str(endoffile_int)
                            g.seek(keep_banm_place)
                            if len(canm_namesize_test_str) < len(endoffile_int_str):
                                endbone_data = search_position                                
                                break

                if endbone_data == search_position:
                    print 'break works, countbones_int = ', countbones_int
                    break
#            banm_chunksize = endbone_data - start_bone_data
            banm_chunksize = start_bip_namesize - start_bone_data


            print 'isbone_str = ', isbone_str
            print 'test_meshname = ', test_meshname
            print mesh_list_str

            print 'banm_chunksize =', banm_chunksize
            print 'end_bone_data = ', endbone_data
            print 'start_bone_data = ', start_bone_data
            banm_chunksize_int = int(banm_chunksize)
            g.seek(start_bone_data)
            banm_data = g.read(banm_chunksize)
            w.write(banm_data)                
            end_banm_data = w.tell()
            if banm_chunksize == 9:
                g.seek(start_bone_data)
                onebyte = g.read(1)
                g.read(8)
                end_banm_minus = end_banm_data - 1
                w.seek(end_banm_minus)
                w.write(onebyte)
            w.seek(banm_ver_loc)
            w.write(ver_read3)
            marshal.dump(banm_chunksize_int,w)


#-------------------BANM needs to be Version 2 
            w.seek(banm_data_start_write)
            w.write(data)
            w.write(ver_read3)
            marshal.dump(two_int, w)
            w.seek(banm_data_start_write)
            w.write(data)
            w.write(banm)

#position for next BANM
            w.seek(end_banm_data)
            g.seek(start_bip_namesize)




#-----------------write CANM chunks
#        sr.close()
        canm = 'CANM'
        g.seek(start_canm_namesize)
        countmesh_int = int(countmesh)
#        print 'first mesh = ', first_mesh
#        print 'first mesh initial = ', first_mesh_initial
        print '----------CANM Data Now--------'
#        print 'isbone = ', isbone
        print 'countbones_int = ', countbones_int
        canm_count = 0

#-----------------Find the end of the CANM Name
#        for k in range(0,countmesh_int):
        for k in range(0,endoffile_int):
            canm_count = canm_count + 1
            canm_namesize_start = g.tell()
            print 'canm_namesize_start =', canm_namesize_start
            checkcanmnamesize = struct.unpack('<L', g.read(4))[0]
            g.seek(canm_namesize_start)
            canm_namesize_read = g.read(4)
            charname = g.read(checkcanmnamesize)
            canm_data_start_write = w.tell()
            w.write(data)
            w.write(canm)
            canm_ver_loc = w.tell()


#correction here for space after name convention in .sgm files
            w.write(ver_read3)
            w.write(ver_read)
            correct_canm_name_size = checkcanmnamesize + 1
            correct_canm_name_size_int = int(correct_canm_name_size)
            marshal.dump(correct_canm_name_size_int, w)
            w.write(charname)
#            print 'canm name written =', charname
            w.write(space)
            endcanmname = w.tell()

#            canm_data = g.read(24)
#            w.write(canm_data)
#            end_canm_data = w.tell()
            w.seek(canm_ver_loc)
            w.write(ver_read3)
            twentyfour = 24
            twentyfour_int = int(twentyfour)
            marshal.dump(twentyfour_int,w)
            w.seek(endcanmname)

#Now we have to search for end of char mesh data
            start_canm_data = g.tell()

            for i in range(1,endoffile_int):

                search_position = g.tell()
                search = g.read(1)
                search_alnum = search.isalnum()
                search_alnum_str = str(search_alnum)
                if search_alnum_str == 'True':
                    g.seek(search_position)
                    is_charmesh = g.read(3)
                    is_charmesh_str = str(is_charmesh)
                    charmesh_alnum = is_charmesh.isalnum()
                    charmesh_alnum_str = str(charmesh_alnum)
                    no_questionmark = string.replace(is_charmesh_str, '?', '')
#                    print '  charmesh_alnum_str =',  charmesh_alnum_str
                    print '  len(no_questionmark) = ', len(no_questionmark)

                    if charmesh_alnum_str == 'True' and len(no_questionmark) == 3:
                        end_canm_data = search_position
                        start_canm_namesize = search_position - 4
                        print 'canm_count =', canm_count
                        print  'countmesh_int =', countmesh_int
#                        print 'is_charmesh_str =', is_charmesh_str
#                        if countmesh_int == canm_count or is_charmesh_str == 'DAT':
                        if is_charmesh_str == 'DAT':

                            start_canm_namesize = search_position
                            nextchunk = search_position
                            break

                        keep_banm_place = g.tell()
#----------------this part checks if CANM namesize makes sense since in some cases random code can be 3 bytes of alphanumeric data
                        g.seek(start_canm_namesize)
                        canm_namesize_test = struct.unpack('<L', g.read(4))[0]

                        canm_namesize_test_str = str(canm_namesize_test)
                        endoffile_int_str = str(endoffile_int)
                        if len(canm_namesize_test_str) < len(endoffile_int_str):
                            canm_namesize_test_int = int(canm_namesize_test)
                            print 'canm_namesize test = ', canm_namesize_test_int
                            g.seek(keep_banm_place)
                            if canm_namesize_test_int < endoffile_int and canm_namesize_test_int != 0:
                                nextchunk = search_position
                                break

                    g.seek(search_position)
                    g.read(1)
            canm_chunksize = start_canm_namesize - start_canm_data
            print 'canm_chunksize =', canm_chunksize
            print 'end_canm_data = ', end_canm_data
            print 'start_canm_data = ', start_canm_data
            canm_chunksize_int = int(canm_chunksize)
            g.seek(start_canm_data)
            canm_data = g.read(canm_chunksize)
            w.write(canm_data)                
            end_canm_write_data = w.tell()
            w.seek(canm_ver_loc)
            w.write(ver_read3)
            marshal.dump(canm_chunksize_int,w)





#-------------------CANM needs to be Version 2 
            w.seek(canm_data_start_write)
            w.write(data)
            w.write(ver_read3)
            marshal.dump(two_int, w)
            w.seek(canm_data_start_write)
            w.write(data)
            w.write(canm)



#position for next CANM
            w.seek(end_canm_write_data)
            if is_charmesh == 'DAT':
                break

#-------------------write ANIM Data chunksize
        anim_data_chunksize = end_canm_write_data - start_anim_data_chunk
        anim_data_chunksize_int = int(anim_data_chunksize)
        w.seek(anim_data_ver_loc)
        w.write(ver_read3)
        marshal.dump(anim_data_chunksize_int,w)


#---------------------Anim Data Data needs to be version 3
        w.seek(start_anim_fold_chunk)
        w.write(fold)
        w.write(ver_read3)
        marshal.dump(three_int, w)
        w.seek(start_anim_fold_chunk)
        w.write(fold)
        w.write(data)




#---------------------write anim FOLD chunksize        

        anim_fold_chunksize = end_canm_write_data - start_anim_fold_chunk
        anim_fold_chunksize_int = int(anim_fold_chunksize)
        w.seek(anim_fold_ver_loc)
        w.write(ver_read3)
        marshal.dump(anim_fold_chunksize_int,w)

#---------Anim FOLD needs to be version 2
        w.seek(start_write_anim_fold)
        w.write(fold)
        w.write(ver_read3)
        marshal.dump(two_int, w)
        w.seek(start_write_anim_fold)
        w.write(fold)
        anim = 'ANIM'
        w.write(anim)
        





            
        w.seek(end_canm_write_data)
#        nextchunk = g.tell()
        print 'canm_count = ', canm_count
        print 'countmesh_int = ', countmesh_int
        print 'nextchunk after canms =', nextchunk

#--------------------------------------------------------This seems to be the source of errors between files.  How to resove differing CANM conventions
#        if canm_count == countmesh_int:
#            nextchunk = nextchunk + 4

#            nextchunk = nextchunk + 4
#        break
        

#write new chunksize to RSGM


        
        rsgm_chunksize = end_canm_write_data - start_rsgm_chunk
        rsgm_chunksize_int = int(rsgm_chunksize)
        w.seek(rsgm_write_ver_loc)
        w.write(ver_read3)
        marshal.dump(rsgm_chunksize_int, w)
        w.seek(rsgm_write_ver_loc)
        w.write(ver_read)
        w.seek(end_canm_write_data) 

        if nextchunk > endoffile:
            w.close()
            Hint.mainloop()
            break


    if nextchunk > endoffile:
        w.close()
        print 'Enjoy your SGM!'
        Hint.mainloop()
        break

    g.seek(nextchunk)
    print 'end of writing, nextchunk = ', nextchunk

