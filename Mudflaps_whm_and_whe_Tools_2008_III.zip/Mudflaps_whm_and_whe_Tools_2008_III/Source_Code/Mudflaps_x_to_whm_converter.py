#to do

#1) root bone should be bone number -1.-Done
#2) bones need to be parented correcty even though they are not listed based on parenting in the x file from Blender - done
#----need to create a parenting list and use that to assign bone numbers - Done
#3) RSGM version should be 1-Done
#4) skel is supposed to go before MSGR and after the last CHAN- Done
#5) Need a method of calculating volume of BVOL based on vert data coordinates  max and min. Done for one mesh at a time
#7) Animations need to be supported.
#8) Bones aren't oriented right in the whm.
#9) Need to fix dependence on Space Marine.whm example file.




#Script to convert x files from Blender into to the MSLC chunk for the WHM files.
#Then use IBBoard's Smart Chunky Viewer to cut and paste the new chunk into an existing WHM for a map object
# for Dawn of War Object Editor


#When exporting a .x file from blender make sure that "bi normals" is selected so that you get one normal for every vertex.  
#  The other options will produce double the amount of normals which causes an error in this script.


#This organization also applies to WHMs so I think I have inadvertantly come across a way to extract mesh data from WHM without using Santos 3dsmax scripts. Mesh data in WHMs can be found here: RSGM\MSGR\MSLC\DATA 
#After the DOW chunky header info in DATA is a 4-byte longint magic number. This number is the number of tris or vertex vectors in the mesh. This number governs the number of bytes in a certain section of data. After that is a 4-byte Longint number '37' not sure what that is for but t is in all the sgm and whm files. Then the mesh data starts. 

#There are 3 groups of data in mesh DATA folder that run immediatley after each other. 

#Group 1 MESH - three 4-byte floats per tris

#Group 2 Skinweights - 16 bytes per tris, skinwights for 3 bones (4-byte float), then four bone index numbers 1-byte (chars)
#Group 3 MESHnormals three 4-byte floats per tris 
#Group 4 UV Coordinates two 4-byte floats per tris 

#Then there is the title of the Material for the mesh. 

#Then things get weird. After the name of the Material is a 4-byte longint number. Divide this by 3 to get the number of faces. 

#Then the facenumber data follows, three 2-byte integers per face. 





 
import tkFileDialog


import Tkinter
import struct
import marshal
import string
import math
import binascii
import string



#get a file to use as example code


ex = open('space_marine.whm', 'rb')

ex_all_data_to_SSHR = ex.read(160)  # skips SHDR

ex.seek(147)
blank_byte = ex.read(1)


ex.seek(3288)


#-------------------------------read MSGR header, 40 plus 13 = 53
msgr_header = ex.read(53)
ex.seek(3343)
data_data_header = ex.read(33)
#ex.close()




from Tkconstants import *
Hint = Tkinter.Tk()
frame = Tkinter.Frame(Hint, relief=RIDGE, borderwidth=2)
frame.pack(fill=BOTH,expand=1)
label = Tkinter.Label(frame, text="OPEN Hint \n This tool can open .x files for conversion to .whm")
label2 = Tkinter.Label(frame, text="File Use \n Save the converted file as a .whm file in your mod directory, data/art/ebps path, \n convert it to a sgm using the whm_to_sgm_for_blender_export converter, \n then open the .sgm in the Object Editor.")
label.pack(fill=X, expand=1)
label2.pack(fill=X, expand=1)
button = Tkinter.Button(frame,text="Close Hints",command=Hint.destroy)
button.pack(side=BOTTOM)

zero = 0
zero_int = int(zero)

two = 2
two_int = int(two)
ten = 10
ten_int = int(ten)

filetoparse = tkFileDialog.askopenfilename(filetypes=[("x", "x")], title = 'Choose a .x file to convert to .whm format')


 

filetowrite = tkFileDialog.asksaveasfilename(filetypes=[("WHM", "WHM")], title = 'Save exported .WHM file as.....', defaultextension = ".whm")




#-------------get texture filename from user and mangle it to match WHM, rsh and rtx file format


texture = tkFileDialog.askopenfilename(filetypes=[("*", "*")], title = 'Select the correct wtp, rsh, or rtx texture file, must have Data/Art in the pathname ', defaultextension = ".wtp, .rsh, .rtx" )

#make lower case only
texture_l = string.lower(texture)

text_fix = 'art/ebps'
default_fix = '_default'
rsh_fix = '.rsh'
rtx_fix = '.rtx'

text_address = string.find(texture_l, text_fix)
text_length = string.find(texture_l, default_fix)
if text_length == -1:
    text_length = string.find(texture_l, rsh_fix)
if text_length == -1:
    text_length = string.find(texture_l, rtx_fix)


text_dif = text_length - text_address


t = open('texture_edit.dat', 'wb')
t.write(texture_l)
t.close()

t_o = open('texture_edit.dat', 'rb')

t_o.read(text_address)
texture_path = t_o.read(text_dif)
texture_path_length = len(texture_path)
t_o.close



w = open(filetowrite,'wb')
#template = open('template.whm', 'rb')

#w.write(msgr_header)
#w.write(data_data_header)


g = open(filetoparse,'rb')
s = open('bonelist.dat','wb')


#relic_header = template.read(24)
#w.write(relic_header) 



g.read()
endoffile = g.tell()
endoffile_int = int(endoffile)
count_colon = 0
count_comma = 0
count_quote = 0
g.seek(0)

print g
print endoffile_int


mesh_float_list = []
meshnormal_float_list = []
uv_float_list = []
bone_list = []    #list of bone names
bone_number_index_list = []     #list of bone numbers based on parenting indexed back to bone_list

bone_namelength_list = []
bone_numbers_list = []
all_bones_list = []  #holds all the SKEL lists
vert_numbers_list = []
vert_skinweight_list = []
vertnumbers_int = 1
done_meshnormal = 0
done_uv = 0
vert_num_int_total = 0
skinweight_list = []

m_list = []
ismesh_old = 1
start_number = int(g.tell())
count_space = 0
got_root_bone = 0
root_bone_end_int = int(0)
bone_look_int = endoffile_int
bone_matrix_list = []
count_end_brackets = 0
count_end_brackets_old = 0
last_bone_number = -2
bone_count_skip = 2
old_length_bone_list = 1

#lists to determine bvol dimensions
x_vert_num_list = []
y_vert_num_list = []
z_vert_num_list = []




#--------------------------------write headers to SSHR


w.write(ex_all_data_to_SSHR)
w_end = w.tell()

#-------------------------------------------write------------SSHR chunk starting at chunk size

sshr_chunk_size = texture_path_length + 4

sshr_chunk_size_int = int(sshr_chunk_size)

sshr_chunk_size_longint = struct.pack('<i',sshr_chunk_size_int)

z = open('write_float.dat', 'wb')
marshal.dump(sshr_chunk_size_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
sshr_chunk_size_int_again = y.read(4)
w.write(sshr_chunk_size_int_again)

#-----------------------------------------write length of SSHR shader name

sshr_chunk_size = texture_path_length + 1

sshr_chunk_size_int = int(sshr_chunk_size)

sshr_chunk_size_longint = struct.pack('<i',sshr_chunk_size_int)

z = open('write_float.dat', 'wb')
marshal.dump(sshr_chunk_size_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
sshr_chunk_size_int_again = y.read(4)
w.write(sshr_chunk_size_int_again)

#----------------------------write shader name plus one byte of blank

w.write(texture_path)
w.write(blank_byte)

#----------------------------write path length

sshr_chunk_size = texture_path_length

sshr_chunk_size_int = int(sshr_chunk_size)

sshr_chunk_size_longint = struct.pack('<i',sshr_chunk_size_int)

z = open('write_float.dat', 'wb')
marshal.dump(sshr_chunk_size_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
sshr_chunk_size_int_again = y.read(4)
w.write(sshr_chunk_size_int_again)

w.write(texture_path)
w_end = w.tell()









#----------------------------------Look for some Mesh data one byte at a time

for i in range(1,endoffile_int):

    search_position = g.tell()
    search = g.read(1)
    search_str = str(search)
    lookforendof_str = 1

#--------------------------------Create Bone Parenting Heirarchy

    if search_str == 'E':
        print search
        g.seek(search_position)
        is_end_bone = g.read(15)
        print is_end_bone

        if got_root_bone == 0 and is_end_bone == 'End of the Bone':
            g.read(1)
            start_root_bone = g.tell()
            for i in range(1,endoffile_int):
                root_bone_position = g.tell()
                count_space = int(i)
                is_space = g.read(1)
                is_space_str = str(is_space)
                print 'is_space_str = ', is_space_str
                if is_space_str == ' ':
                    count_space = count_space - 1
                    print count_space
                    g.seek(start_root_bone)
                    root_bone = g.read(count_space)
                    bone_list.append(root_bone)
                    bone_namelength_list.append(count_space)
                    bone_number_index = last_bone_number + 1
                    last_bone_number = bone_number_index
                    bone_number_index_list.append(bone_number_index)

                    print 'root_bone = ', root_bone
                    got_root_bone = 1
                    print 'got_root_bone = ', got_root_bone
                    root_bone_end = g.tell()
                    root_bone_end_int = int(root_bone_end)

                    g.seek(start_number)
                    print 'start_number after Root Bone = ', start_number


#----------------------Now look for the rest of the bones in the parenting list
                    for i in range(1,endoffile_int):

                        bone_look = g.tell()
                        bone_look_int = int(bone_look)


                        if root_bone_end_int == bone_look_int:#------------This will stop looking
                            print 'break at root_bone_end_int == bone_look_int', root_bone_end_int, bone_look_int
                            break
                        search_position = g.tell()
                        search = g.read(1)
                        search_str = str(search)

#--------------------------------Look for Root Bone in Parenting list

                        if search_str == 'F':
                            print search
                            g.seek(search_position)
                            is_frame = g.read(6)
                            print is_frame
                            if is_frame == 'Frame ':
                                is_root_bone = g.read(count_space)
                                if is_root_bone == root_bone:
                                    print 'is_root_bone and root_bone = ', is_root_bone


#----------------------Get Root Bone Matrix Data

                                    for i in range(1,endoffile_int):


                                        bone_look = g.tell()
                                        bone_look_int = int(bone_look)


                                        if root_bone_end_int == bone_look_int:#------------This will stop looking
                                            print 'break at root_bone_end << bone_look after the root'
                                            break

                                        search_position = g.tell()
                                        search = g.read(1)
                                        search_str = str(search)


                                        if search_str == 'F':
                                            print search
                                            g.read(23)
                                            for b in range(0,16):
                                                b_int = int(b)
                                                start_matrix_number = g.tell()
                                                for i in range(1,endoffile_int):
                                                    i_bone_int = int(i)

                                                    search_position = g.tell()
                                                    search = g.read(1)
                                                    search_str = str(search)
                                                    if search_str == ',' or search_str == ';':
                                                        g.seek(start_matrix_number)
                                                        matrix_contents = g.read(i_bone_int)
                                                        matrix_contents_strip = string.strip(matrix_contents)
                                                        matrix_contents_strip = string.strip(matrix_contents_strip,',')
                                                        matrix_contents_strip = string.strip(matrix_contents_strip, ';')
                                                        search_position = g.tell()

                                                        bone_matrix_list.append(matrix_contents_strip)
                                                        print 'root bone matrix Just Root= ', bone_matrix_list
                                                        break

                                                        

#-----------Now get the rest of the bones and count '}' when they occur until Frame, ignore frametransformmatrixes until reading them after 'Frame'

                                            for i in range(1,endoffile_int):


                                                bone_look = g.tell()
                                                bone_look_int = int(bone_look)
                                                if root_bone_end_int == bone_look_int:#------------This will stop looking
                                                    print 'break of bone loop at root_bone_end == bone_look after the root'
                                                    break


 
                                                search_position = g.tell()
                                                search = g.read(1)
                                                search_str = str(search)


#---------------------------------------------Count end brackets '}' to determine parenting of bones outside usual order

                                                if search_str == '}':
                                                    count_end_brackets = count_end_brackets + 1
                                                    print 'count_end_brackets = ', count_end_brackets



#--------------------------------Look for Bones

                                                if search_str == 'F':
                                                    print search
                                                    g.seek(search_position)
                                                    is_frame = g.read(6)
                                                    print is_frame
                                                    if is_frame == 'Frame ':

                                                        start_new_bone_name = g.tell()

                                                        for d in range(1,endoffile_int):

                                                            d_int = int(d)

                                                            search_position = g.tell()
                                                            search = g.read(1)
                                                            search_str = str(search)
                                                            print 'search_str for bone name =', search_str

#--------------------------------Look for Bones

                                                            if search_str == '{':
                                                                print search
                                                                g.seek(start_new_bone_name)
                                                                d_int_minus = d_int - 2
                                                                new_bone_name = g.read(d_int_minus)
                                                                new_bone_name_str = str(new_bone_name)
                                                                new_bone_name_strip = string.strip(new_bone_name_str)
                                                                new_bone_name_length = len(new_bone_name_strip)

                                                                bone_list.append(new_bone_name_strip)
                                                                bone_namelength_list.append(new_bone_name_length)


#-------------------------------This is where bone_number based on parenting is assigned
                                                                if count_end_brackets == 1:
                                                                    bone_number_index = last_bone_number + 1
                                                                    bone_number_index_list.append(bone_number_index)
                                                                    last_bone_number = last_bone_number + 1
                                                                    

                                                                if count_end_brackets >> 1:

                                                                    bone_skip = count_end_brackets -1
                                                                    bone_skip_in_index = len(bone_number_index_list) - bone_skip
                                                                    skipped_bone_number = bone_number_index_list[bone_skip_in_index]
                                                                    bone_number_index_list.append(skipped_bone_number)
                                                                    last_bone_number = last_bone_number + 1 # --------------not sure if this is right makes sense if number refers to bone parented to and not address in the list

                                                                break

                                                    if is_frame == 'FrameT':
                                                        print 'search after frametransformmatrix = ', search
                                                        g.seek(search_position)
                                                        g.read(23)
                                                        count_end_brackets = 0
                                                        for b in range(0,16):
                                                            start_matrix_number = g.tell()
                                                            for i in range(1,endoffile_int):
                                                                i_bone_int = int(i)
   
                                                                search_position = g.tell()
                                                                search = g.read(1)
                                                                search_str = str(search)
                                                                if search_str == ',' or search_str == ';':
                                                                    g.seek(start_matrix_number)
                                                                    matrix_contents = g.read(i_bone_int)
                                                                    matrix_contents_strip = string.strip(matrix_contents)
                                                                    matrix_contents_strip = string.strip(matrix_contents_strip,',')
                                                                    matrix_contents_strip = string.strip(matrix_contents_strip, ';')
     
                                                                    bone_matrix_list.append(matrix_contents_strip)

                                                                    print 'root bone matrix = ', bone_matrix_list
                                                                    print 'bone_list =', bone_list
                                                                    print 'bone_number_index_list = ', bone_number_index_list
                                                                    print 'new_bone_name = ', new_bone_name
                                                                    print 'new_bone_name_strip =', new_bone_name_strip
	                                                        
                                                                    break
	 
                                                   

                                                       
                                            break



#--------------Need to count '}' to determine how far back the bone is parented
#--------------one '}' is for the frametransform matrix on each bone and can be ignored
#--------------More than one '}' means that the parenting on a bone further up the chain is ending
#--------------An that the bone for that parent need to be minus the number of '}'s.



#--------------Now done with bone parenting list, now search for mesh data


                    g.seek(start_number)


                    break 











    if search_str == 'M' or search_str == 'm':
        print search

#------------Now make a variable to kill the "End of" problem
        search_position_minus = search_position -7
        g.seek(search_position_minus)
        lookforendof = g.read(3)
        lookforendof_str = str(lookforendof)

        g.seek(search_position)
        ismesh = g.read(6)
        m_list.append(ismesh)
        print ismesh

        if ismesh == 'Mesh {' or ismesh == 'mesh {' and lookforendof_str != 'End':
            start_number = g.tell()


#Get Total Number of Verts

            for i in range(1,endoffile_int):
                vert_position = g.tell()
                count_colon = 1 + count_colon
                is_colon = g.read(1)
                if is_colon == ';':
                    count_colon = count_colon - 1
                    print count_colon
                    next_float = g.tell()
                    g.seek(start_number)
                    vert_num = g.read(count_colon)
                    print 'total number of verts = ', vert_num
                    vert_num_int = int(vert_num)
                    vert_num_int_total = vert_num_int
                    print vert_num
                    count_colon = 0
                    g.read(1)
                    start_number = g.tell()
                    break 

#Now read and write verts 3 times

            for i in range(0,vert_num_int):

                for k in range(0,3):
                    k_int = int(k)

                    for i in range(1,endoffile_int):
                        vert_position = g.tell()
                        count_colon = 1 + count_colon
                        is_colon = g.read(1)
                        if is_colon == ';':
                            count_colon = count_colon - 1
                            g.seek(start_number)
                            vert_num = g.read(count_colon)


#---------------Now put vert_num as 4-byte IEEE Singleint Float in mesh_float_list
#                            z = open('write_float.dat', 'wb')
                            vert_num_float = float(vert_num)



#------------------------add to lists to calculate bvol later
                            if k_int == 0:
                                x_vert_num_list.append(vert_num_float)
                            if k_int == 1:
                                y_vert_num_list.append(vert_num_float)
                            if k_int == 2:
                                z_vert_num_list.append(vert_num_float)


                                


#--------------------Now put vert_num as 4-byte IEEE Singleint Float in meshnormal_float_list
                            mesh_float_list.append(vert_num_float) 




                            g.read(2)
                            start_number = g.tell()
#code for getting rid of 2-bit "oa od" line break
                            if k == 2:
                               g.read(1)
                               endline = 'end'
                               start_number = g.tell()
                            count_colon = 0
                            break 




#----------------Now lets look for meshnormal data



        if done_meshnormal != 1 and ismesh == 'MeshNo':

            if done_meshnormal == 1:
               start_number = g.tell()
            g.read(9)
            start_number = g.tell()
            mesh_normal_text = 'MeshNormals'

#Get Total Number of Verts

            for i in range(1,endoffile_int):
                vert_position = g.tell()
                count_colon = 1 + count_colon
                is_colon = g.read(1)
                if is_colon == ';':
                    count_colon = count_colon - 1
                    print count_colon
                    next_float = g.tell()
                    g.seek(start_number)
                    vert_num = g.read(count_colon)
                    print vert_num
                    vert_num_int = int(vert_num)
#                    ver_num_float = struct.pack(('<f', vert_num)[0])
#                    w.write(vert_num)
                    print vert_num
                    count_colon = 0
                    g.read(1)
                    start_number = g.tell()
                    break 

#Now read and write verts 3 times

            for i in range(0,vert_num_int):

                for k in range(0,3):

                    for i in range(1,endoffile_int):
                        vert_position = g.tell()
                        count_colon = 1 + count_colon
                        is_colon = g.read(1)
                        if is_colon == ';':
                            count_colon = count_colon - 1
                            g.seek(start_number)
                            vert_num = g.read(count_colon)
                            vert_num_float = float(vert_num)

                            ak = 'ak'


#--------------------Now put vert_num as 4-byte IEEE Singleint Float in meshnormal_float_list
                            meshnormal_float_list.append(vert_num_float) 


#---------------Now write vert_num as 4-byte IEEE Singleint Float


#                            z = open('write_float.dat', 'wb')
#                            vert_num_float = float(vert_num)
#                            z_float = struct.pack('f', vert_num_float)
#                            marshal.dump(z_float, z)
#
#                            z.close()

#                            y = open('write_float.dat', 'rb')
#                            y.read(5)
#                            vert_num_float_again = y.read(4)

#                            z = open('write_float.dat', 'wb')
#                            w.write(vert_num_float_again)
#                            z.close()

#--------------------------Done Writing FLoat

#                            w.write(ak)
                            g.read(2)
                            start_number = g.tell()
#code for getting rid of 2-bit "oa od" line break
#                            if k == 2:
#                               g.read(1)
#                               endline = 'end'
#                               w.write(endline)
#                               start_number = g.tell()
                            count_colon = 0
                            done_meshnormal = 1 
                            break 

#------------------Now get number of faces

            for i in range(1,endoffile_int):
                vert_position = g.tell()
                count_colon = 1 + count_colon
                is_colon = g.read(1)
                if is_colon == ';':
                    count_colon = count_colon - 1
                    print 'count_colon for face_num reading = ', count_colon
                    next_float = g.tell()
                    g.seek(start_number)
                    vert_num = g.read(count_colon)
                    print 'file location when reading face_num =', start_number 
                    print vert_num
                    vert_num_int = int(vert_num)
#                    ver_num_float = struct.pack(('<f', vert_num)[0])
#                    w.write(vert_num)
                    print vert_num
                    count_colon = 0
                    g.read(1)
                    start_number = g.tell()
                    total_faces = vert_num_int
                    start_face_data = g.tell()
                    break 


#---------------------Now get number of verts per face

            for i in range(0, vert_num_int):
                g.read(2)
                number_for_face = g.read(1)
                print 'number_for_fac = ', number_for_face
                number_for_face_int = int(number_for_face)
                number_for_face_int_minus = number_for_face_int - 1
                g.read(1)
                start_number = g.tell()
                  

#----------Now read and write face verts number_for_face times

                for k in range(0,number_for_face_int):

                    for i in range(1,endoffile_int):
                        vert_position = g.tell()
                        count_comma = 1 + count_comma
                        is_comma = g.read(1)
                        if is_comma == ',' or is_comma == ';':
                            count_comma = count_comma - 1
                            g.seek(start_number)
                            vert_num = g.read(count_comma)
#---------Write 4-byte Longint here 
                            if k <> number_for_face_int:
                                g.read(2)
                            start_number = g.tell()
                            count_comma = 0
                            break 



#----------------Now Search for MeshTexture Coordinates data

        if ismesh == 'MeshTe' or ismesh == 'meshte' and lookforendof_str != 'End':

            can_see_uv = 'yes'
            g.read(15)
            start_number = g.tell()
            if done_uv == 1:
                break
            mesh_tex_text = 'Mesh Texture Coordinates'
#            w.write(mesh_tex_text)

#Get Total Number of Verts

            for i in range(1,endoffile_int):
                vert_position = g.tell()
                count_colon = 1 + count_colon
                is_colon = g.read(1)
                if is_colon == ';':
                    count_colon = count_colon - 1
                    print count_colon
                    next_float = g.tell()
                    g.seek(start_number)
                    vert_num = g.read(count_colon)
                    print vert_num
                    vert_num_int = int(vert_num)
#                    ver_num_float = struct.pack(('<f', vert_num)[0])
#                    w.write(vert_num)
                    print 'for uvs vert_num_int = ', vert_num_int
                    count_colon = 0
                    g.read(1)
                    start_number = g.tell()
                    break 


#Now read and write UVs 2 times

            for i in range(0,vert_num_int):

                for k in range(0,2):

                    for i in range(1,endoffile_int):
                        vert_position = g.tell()
                        count_colon = 1 + count_colon
                        is_colon = g.read(1)
                        if is_colon == ';':
                            check_UV_end = g.read(1)
                            count_colon = count_colon - 1
                            g.seek(start_number)
                            vert_num = g.read(count_colon)
                            ak = 'ak'
                            vert_num_float = float(vert_num)

#--------------------Now put vert_num as 4-byte IEEE Singleint Float in meshnormal_float_list
                            uv_float_list.append(vert_num_float) 



                            if check_UV_end == ';':
                                check_UV_end = 1
                                done_uv = 1
                                break

                            g.read(1)
                            start_number = g.tell()
#code for getting rid of 2-bit "oa od" line break
                            if k == 1:
                                g.read(2)
                                endline = 'end'
                                start_number = g.tell()
                            count_colon = 0
                            break 

                    if check_UV_end == 1:
                        break


    


#-------Find Skinmeshheader bone data to make list of Bones and Skinweights


#-----This needs to read and write bones based on the parenting order
#------so this needs to be inside another "if" statement based on parenting order
print 'start looking for skinmesh data'
g.seek(start_number)
for i in range(1,endoffile_int):

    search_position = g.tell()
    search = g.read(1)
    search_str = str(search)
#    print search_str
    if search_str == 'S' or search_str == 's':
        print search
        g.seek(search_position)
        skinmesh = g.read(13)
        print skinmesh
        if skinmesh == 'SkinWeights {' or skinmesh == 'skinweights {':
            start_number = g.tell()

#Get Name of Bone

            for i in range(1,endoffile_int):

                vert_position = g.tell()
                count_colon = 1 + count_colon
                is_colon = g.read(1)
                is_colon_str = str(is_colon)
                if is_colon_str == ';':
                    end_bone_name = g.tell() -1
                    g.seek(start_number)
                    for i in range(1,count_colon):
                        vert_position = g.tell()
                        count_quote = 1 + count_quote
                        is_quote = g.read(1)
                        if is_quote == '"':
                            start_bone_name = g.tell()
                            bone_namelength = end_bone_name - start_bone_name - 1
                            bone_name = g.read(bone_namelength)
                            count_quote = 0

                            break
                    print bone_name
#                    bone_list.append(bone_name)
#                    bone_namelength_list.append(bone_namelength)

                    
                    
                    print bone_list        
                    print 'bone_namelength_list =', bone_namelength_list

#------------------------Need to fix this, bone_number should be assigned
#------------------------Based on location in the parenting list. Not as is occurs.

                    bone_name_str = str(bone_name)
                    index_of_bone_name = bone_list.index(bone_name_str)
                    index_of_bone_name_int = int(index_of_bone_name)

                    bone_number = bone_number_index_list[index_of_bone_name_int]
                    print len(bone_list)     
                    count_colon = 0
                    g.read(1)
                    g.read(1)
    
                    start_number = g.tell()
                    break 

#---------------get number of verts skinned to the bone


            for i in range(1,endoffile_int):
                found_number = 0
                vert_position = g.tell()
                count_colon = 1 + count_colon
                is_colon = g.read(1)
                if is_colon == ';':
                    end_vertnumbers = g.tell()
                    print 'found semicolon'
                    g.seek(start_number)

                    for i in range(1,endoffile_int):
                        is_alpha = g.read(1)
                        is_alpha_true = is_alpha.isalnum()
                        is_alpha_true_str = str(is_alpha_true)
                        if is_alpha_true_str == 'True':
                            start_vertnumbers = g.tell()
                            start_vertnumbers_minus = start_vertnumbers - 1
                            g.seek(start_vertnumbers_minus)
                            vertnumbers_length = end_vertnumbers - start_vertnumbers
                            vertnumbers = g.read(vertnumbers_length)
                            vertnumbers_int = int(vertnumbers)
                            count_quote = 0

                            print 'number of verts on this bone =', vertnumbers_int
                            found_number = 1
                            break
                if found_number == 1:
                    g.read(1)
                    start_number = g.tell()
                    break


#now read in the vert numbers

            for i in range(0,vertnumbers_int):

                for i in range(1,vertnumbers_int):
    
                    vert_position = g.tell()
                    count_colon = 1 + count_colon
                    is_colon = g.read(1)
                    if is_colon == ',' or is_colon == ';':
                        end_vertnumbers = g.tell()
                        g.seek(start_number)
                        lookup = end_vertnumbers - start_number
                        lookup_int = int(lookup)
    
                        for d in range(1,lookup_int):
                            is_alpha = g.read(1)
                            is_alpha_true = is_alpha.isalnum()
                            is_alpha_true_str = str(is_alpha_true)
                            if is_alpha_true_str == 'True':
                                start_vertnumbers = g.tell()
                                start_vertnumbers_minus = start_vertnumbers - 1
                                g.seek(start_vertnumbers_minus)
                                vertnumbers_length = end_vertnumbers - start_vertnumbers
                                vert_in_list = g.read(vertnumbers_length)
                                vert_in_list_int = int(vert_in_list)
                                count_quote = 0

                                vert_numbers_list.append(vert_in_list_int)
                                bone_numbers_list.append(bone_number)

                                g.read(2) # get past "," again
                                start_number = g.tell()
                                break


                        if is_alpha_true_str == 'True':
                            break

                print bone_numbers_list



#now read in the vert skinweights

            for i in range(0,vertnumbers_int):

                for i in range(1,vertnumbers_int):
    
                    vert_position = g.tell()
                    count_colon = 1 + count_colon
                    is_colon = g.read(1)
                    if is_colon == ',' or is_colon == ';':
                        end_vertnumbers = g.tell()
                        g.seek(start_number)
                        lookup = end_vertnumbers - start_number
                        lookup_int = int(lookup)
    
                        for d in range(1,lookup_int):
                            is_alpha = g.read(1)
                            is_alpha_true = is_alpha.isalnum()
                            is_alpha_true_str = str(is_alpha_true)
                            if is_alpha_true_str == 'True':
                                start_vertnumbers = g.tell()
                                start_vertnumbers_minus = start_vertnumbers - 1
                                g.seek(start_vertnumbers_minus)
                                vertnumbers_length = end_vertnumbers - start_vertnumbers
                                skinweight_in_list = g.read(vertnumbers_length)
                                count_quote = 0

                                vert_skinweight_list.append(skinweight_in_list)
                                g.read(2) # get past "," again
                                start_number = g.tell()
                                break


                        if is_alpha_true_str == 'True':
                            break







            print 'length of list vert_numbers_list', len(vert_numbers_list)
            print 'length of list vert_skinweight_list', len(vert_skinweight_list)
            print 'length of list bone_numbers_list', len(bone_numbers_list)

            print 'vertnumbers_int = ', vertnumbers_int 


#Now to read in Data for the SKEL/data Chunk

#This is where SKEL Data is read from the Frametransform Matrices at the end of the 
#skinweights.  This matrix is the Offset frame transfrom matrix that encompasses all the
#offsets from the parents so it shows the offset needed to determine the bone's true position and rotation
#The following data needs to be read in

#Here is the Bone info from Santos script:
##
#struct bonedata (name, level, pos_x, pos_y, pos_z, rot_x, rot_y, rot_z, rot_w)				-- Structure To Hold Bone Data (4, X, 4, 28)
#
#bone.name += char
#
#bone.level = ReadLong file																	-- Read Bone Hierarchy Level
#bone.pos_x = ReadFloat file																	-- Read Bone X Position
#bone.pos_y = ReadFloat file																	-- Read Bone Y Position
#bone.pos_z = ReadFloat file																	-- Read Bone Z Position
#bone.rot_x = ReadFloat file																	-- Read Bone X Rotation
#bone.rot_y = ReadFloat file																	-- Read Bone Y Position
#bone.rot_z = ReadFloat file																	-- Read Bone Z Position
#bone.rot_w = ReadFloat file																	-- Read Bone W Position
#
#
#4 bytes at start of data indicate its bone order
#
#4 bytes at the end indicate the Longint lengtht of the name for the next bone.
#
#28 bytes for bone.pos and bone.rot.  


#a_list in the code below contains the frametransform matric for the last bone in the 
#x file.  Need to fix this so that each bone gets included, instead of overwriting a_list
# for each bone, append it or make a new list (never have figured that out!)

# This part below creates a list "all_bones_list" that stores the frametransform matrix data
# in the same order as the bone names are listed in "bone_list" and bone_namelength_list  

##It is also the same order that the bones are listed in the MSLC/Data chunk. It is based on the way it islisted after the skinweights
#after each bone its ranking (Santos bone.level) in the list is listed from 0 to max number of bones.
#next thing to do, figure out which parts of all_bones_list apply to the bone position and rotation
#in 7 floats.



            a = ''

            for i in range(0, 100000):
                b = g.read(1)
                b_isalnum = b.isalnum()
                b_isalnum_str = str(b_isalnum)
                if b_isalnum_str == 'True' or b == '-' or b == ';' or b =='.' or b==',':
                    a = a + b
                check_end = string.count(a, ';;')
                if check_end == 1:
                    break


#cleanup to just numbers and separators by replace spaces and commas with nothing

            a_clean = string.replace(a, ' ', '')
            a_clean = string.replace(a, ';;', '')

# now make a list out the a_clean by splitting it up as indicated by ',' between numbers

            a_list = string.split(a_clean, ',')

            all_bones_list = all_bones_list + a_list







#END SKEL reading part


#Now try write the list that the whm file needs for skinweights



#This Section reads the data from the following lists 



#vert_numbers_list
#vert_skinweight_list
#bone_numbers_list


#and puts it in a new list called whm_skinweights



i = 0
vert_write_count = 0
skinweight_vert_location = 0

bone_zero = 0 #this needs to be fixed to match whats in a whm
skinweight_zero = 0  #this needs to be fixed to match whats in a whm

#this will look for skinweight data based on vert number

vert_numbers_length = len(vert_numbers_list)
vert_numbers_length_minus = vert_numbers_length - 1
len_vert_skinweight_list_minus = len(vert_skinweight_list)

print 'vert_num_int_total = ', vert_num_int_total
print 'len_vert_skinweight_list_minus =', len_vert_skinweight_list_minus
print 'vert_numbers_length =', vert_numbers_length




for i in range(0, vert_num_int_total): 

    vert_write_count = 0

    for v in range(0, len_vert_skinweight_list_minus):  # this will go through whole list of verts for all bones and pick out the verts numerically

        vert_number = vert_numbers_list[v]

        vert_number_int = int(vert_number)

        v_int = int(v)
        i_int = int(i)
	
        if vert_number_int == i_int:   #if vertex in order then write to whm list, need to find way to write bone names at the end, maybe inserting in the list?

            print 'at v = ', v
            print 'index of ', i, '= ', vert_numbers_list.index(i)
            print 'length of vert_skinweight_list =', len(vert_skinweight_list)   

            vert_weight = vert_skinweight_list[v]
            vert_bone = bone_numbers_list[v]


            print 'at v = ', v
            print 'index of ', i, '= ', vert_numbers_list.index(i)        
 


            if vert_write_count == 0:  #write the first skinweight

                skinweight_list.append(vert_weight)  # write skinweight to whm list
                skinweight_vert_location = skinweight_vert_location + 1
                skinweight_list.append(vert_bone)    #write bone_number to whm list

                vert_write_count = vert_write_count + 1
                v_old = v

                print 'at i = ',i, 'vertweight = ', vert_weight
                print 'at i = ', i, 'ver_bone =', vert_bone
                print 'vert_write_count =', vert_write_count
                print 'skinweight_vert_location = ', skinweight_vert_location




            if vert_write_count == 1 and v_old != v_int:


                skinweight_list.insert(skinweight_vert_location, vert_weight)  # insert write skinweight to whm list
                skinweight_list.append(vert_bone)    #write bone_number to end of whm list
                vert_write_count = vert_write_count + 1
                skinweight_vert_location = skinweight_vert_location + 1

                print 'at i = ',i, 'vertweight = ', vert_weight
                print 'at i = ', i, 'ver_bone =', vert_bone
                print 'vert_write_count =', vert_write_count
                v_old = v



            if vert_write_count == 2 and v_old != v_int:


                skinweight_list.insert(skinweight_vert_location, vert_weight)  # insert write skinweight to whm list
                skinweight_list.append(vert_bone)    #write bone_number to end of whm list
                vert_write_count = vert_write_count + 1
                skinweight_vert_location = skinweight_vert_location + 1

                print 'at i = ',i, 'vertweight = ', vert_weight
                print 'at i = ', i, 'ver_bone =', vert_bone
                print 'vert_write_count =', vert_write_count
                v_old = v


            if vert_write_count == 3 and v_old != v_int:  #4th vert weight not written, just bone name, game calculates it as 1-minus other bone weights
				
                skinweight_list.append(vert_bone)    #write bone_number to whm list
                skinweight_vert_location = skinweight_vert_location + 4
                break



#Start here to get correct number of zeros after files

        if vert_write_count == 1 and v_int == vert_numbers_length_minus:  #write the first skinweight


            skinweight_list.insert(skinweight_vert_location,skinweight_zero)  # write skinweight_zero to whm list
            skinweight_vert_location = skinweight_vert_location + 1
            skinweight_list.append(bone_zero)    #write bone_number to whm list


            skinweight_list.insert(skinweight_vert_location,skinweight_zero)  # write skinweight_zero to whm list
            skinweight_vert_location = skinweight_vert_location + 1
            skinweight_list.append(bone_zero)    #write bone_number to whm list


            skinweight_list.append(bone_zero)    #write bone_number to whm list



            skinweight_vert_location = skinweight_vert_location + 4                 

        

        if v == vert_numbers_length_minus and vert_write_count == 2:
            skinweight_list.insert(skinweight_vert_location,skinweight_zero)  # write skinweight_zero to whm list
            skinweight_vert_location = skinweight_vert_location + 1
            skinweight_list.append(bone_zero)    #write bone_number to whm list


            skinweight_list.append(bone_zero)    #write bone_number to whm list

            skinweight_vert_location = skinweight_vert_location + 4                 


        if v == vert_numbers_length_minus and vert_write_count == 3:
            skinweight_list.append(bone_zero)    #write bone_number to whm list
            skinweight_vert_location = skinweight_vert_location + 4                 









print 'length of skinweight_list =', len(skinweight_list)
print 'skinweight list first thirty entries =', skinweight_list[0:30]
print 'vert_numbers_length_minus =', vert_numbers_length_minus
#print 'v = ', v_int
print 'length of mesh_float_list = ', len(mesh_float_list)
print 'length of meshnormal_float_list = ', len(meshnormal_float_list)
print 'length of uv_float_list = ', len(uv_float_list)
print 'start_face_data =', start_face_data 
print 'vert_num_int =', vert_num_int

#Now that we are sure that everything is in lists like it is supposed to be
#now print those lists to a file that matches WHM MSLC Data/data format.
#then write the facenumber data again by moving file to "start_face_data".


#There are 3 groups of data in mesh DATA folder that run immediatley after each other. 



#first,    list the bones, 4-byte Longint bone number based on order in SKEL, then 4-byte length of next bone name

# here are the bonelists to work with

#bone_list = []
#bone_namelength_list = []

#----------------------------------------Now Write SKEL Data


#---------------------------------------------Now write SKEL Chunk


w.seek(w_end)
SKEL = 'SKEL'
DATA = 'DATA'


#---------now get a 4-byte longint 5 for version

five = 5
five_int = int(five)
five_longint = struct.pack('<i', five_int)

z = open('write_float.dat', 'wb')
marshal.dump(five_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
five_int_again = y.read(4)



#------------------------Now get zero longint
zero_longint = struct.pack('<i', zero_int)
z = open('write_float.dat', 'wb')
marshal.dump(zero_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
zero_int_again = y.read(4)




w.write(DATA)
w.write(SKEL)
start_boneskel_ver = w.tell()
w.write(five_int_again)
end_boneskel_ver = w.tell()
w.write(SKEL)  #placeholder for chunk size
w.write(zero_int_again)  #0000 namesize
bone_skel_chunk_start = w.tell()


# here are the bonelists to work with

#bone_list = []  this has the names of the bones
#bone_namelength_list = []
#all_bones_list = has 16 numbers of the Framtransformmatrix for each bone after the skinweights

#--------------------Write Bone info



#start with 4-byte longint "bone_number", ie number of bones

bone_number_int = int(len(bone_list))

bone_number_longint = struct.pack('<i', bone_number_int)

z = open('write_float.dat', 'wb')
marshal.dump(bone_number_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
bone_number_int_again = y.read(4)

w.write(bone_number_int_again)





#-----now list out bone names and data


for i in range(0, len(bone_list)):
    bone_length_w = bone_namelength_list[i]
    bone_name_w = bone_list[i]
    i_bonelength_int = int(bone_length_w)
    i_bonelength_longint = struct.pack('<i', i_bonelength_int)

#write bone length

    z = open('write_float.dat', 'wb')
    marshal.dump(i_bonelength_longint, z)
    z.close()
    y = open('write_float.dat', 'rb')
    y.read(5)
    i_bonelength_again = y.read(4)
    w.write(i_bonelength_again)


#write bone_name


    w.write(bone_name_w)


#write bone number

    i_bone_index = bone_number_index_list[i]
    i_bone_int = int(i_bone_index)
    i_bone_longint = struct.pack('<i', i_bone_int)

    z = open('write_float.dat', 'wb')
    marshal.dump(i_bone_longint, z)
    z.close()
    y = open('write_float.dat', 'rb')
    y.read(5)
    i_bone_again = y.read(4)
    w.write(i_bone_again)






#------------now for the meat of the bone data

#____Info from Santos Script
#bone.level = ReadLong file																	-- Read Bone Hierarchy Level
#bone.pos_x = ReadFloat file																	-- Read Bone X Position
#bone.pos_y = ReadFloat file																	-- Read Bone Y Position
#bone.pos_z = ReadFloat file																	-- Read Bone Z Position
#bone.rot_x = ReadFloat file																	-- Read Bone X Rotation
#bone.rot_y = ReadFloat file																	-- Read Bone Y Position
#bone.rot_z = ReadFloat file																	-- Read Bone Z Position
#bone.rot_w = ReadFloat file																	-- Read Bone W Position
#
#
#4 bytes at start of data indicate its bone order
#
#4 bytes at the end indicate the Longint lengtht of the name for the next bone.




#-----------------write bone position and rotation

    bone_matrix_count_no_minus = 16*i
    bone_matrix_count = bone_matrix_count_no_minus - 1


#------------- Get bone position from last row of Frametransformmatrix after skinweights

    x_pos = float(all_bones_list[bone_matrix_count+13])
    y_pos = float(all_bones_list[bone_matrix_count+14])
    z_pos = float(all_bones_list[bone_matrix_count+15])

#------------- Get bone rotation from first 3 rows of Frametransformmatrix after skinweights


    x_rot = math.asin(float(all_bones_list[bone_matrix_count+10]))
    y_rot = math.asin(float(all_bones_list[bone_matrix_count+9]))
    z_rot = math.asin(float(all_bones_list[bone_matrix_count+5]))
    w_rot = all_bones_list[bone_matrix_count+16]



#----------write x_pos

    z = open('write_float.dat', 'wb')
    z_float = struct.pack('f', x_pos)
    marshal.dump(z_float, z)
    z.close()
    y = open('write_float.dat', 'rb')
    y.read(5)
    x_pos_again = y.read(4)
    w.write(x_pos_again)


#----------write y_pos

    z = open('write_float.dat', 'wb')
    z_float = struct.pack('f', y_pos)
    marshal.dump(z_float, z)
    z.close()
    y = open('write_float.dat', 'rb')
    y.read(5)
    y_pos_again = y.read(4)
    w.write(x_pos_again)



#----------write z_pos

    z = open('write_float.dat', 'wb')
    z_float = struct.pack('f', z_pos)
    marshal.dump(z_float, z)
    z.close()
    y = open('write_float.dat', 'rb')
    y.read(5)
    z_pos_again = y.read(4)
    w.write(z_pos_again)


#----------write x_rot

    z = open('write_float.dat', 'wb')
    x_rot_float = float(x_rot)
    z_float = struct.pack('f', x_rot_float)
    marshal.dump(z_float, z)
    z.close()
    y = open('write_float.dat', 'rb')
    y.read(5)
    x_rot_float_again = y.read(4)
    w.write(x_rot_float_again)

#----------write y_rot

    z = open('write_float.dat', 'wb')
    y_rot_float = float(y_rot)
    z_float = struct.pack('f', y_rot_float)
    marshal.dump(z_float, z)
    z.close()
    y = open('write_float.dat', 'rb')
    y.read(5)
    y_rot_float_again = y.read(4)
    w.write(y_rot_float_again)

#----------write Z_rot

    z = open('write_float.dat', 'wb')
    z_rot_float = float(z_rot)
    z_float = struct.pack('f', z_rot_float)
    marshal.dump(z_float, z)
    z.close()
    y = open('write_float.dat', 'rb')
    y.read(5)
    z_rot_float_again = y.read(4)
    w.write(z_rot_float_again)

#----------write w_rot

    z = open('write_float.dat', 'wb')
    w_rot_float = float(y_rot)
    z_float = struct.pack('f', w_rot_float)
    marshal.dump(z_float, z)
    z.close()
    y = open('write_float.dat', 'rb')
    y.read(5)
    w_rot_float_again = y.read(4)
    w.write(w_rot_float_again)






bone_skel_chunk_end = w.tell()
bone_skel_chunk_size = bone_skel_chunk_end - bone_skel_chunk_start

print 'bone_skel_chunk_size =', bone_skel_chunk_size


bone_skel_chunk_size_int = int(bone_skel_chunk_size)

bone_skel_chunk_size_longint = struct.pack('<i',bone_skel_chunk_size)

z = open('write_float.dat', 'wb')
marshal.dump(bone_skel_chunk_size_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
bone_skel_chunk_size_int_again = y.read(4)

w.seek(end_boneskel_ver)

w.write(bone_skel_chunk_size_int_again)

w.write(zero_int_again)

w.seek(bone_skel_chunk_end)


#-------------------------starting to write MSGR and MSLC after SKEL--------------------------
start_msgr_header = w.tell()

start_msgr_chunk = start_msgr_header + 20
start_msgr_chunk_int = int(start_msgr_chunk)

mslc_chunk_size_location = start_msgr_header + 32
mslc_chunk_size_location_int = int(mslc_chunk_size_location)


w.write(msgr_header)

start_mslc_chunk = w.tell()
start_mslc_chunk_int = int(start_mslc_chunk)

w.write(data_data_header)
start_mslc_data_data_chunk = w.tell()
start_mslc_data_data_chunk_int = int(start_mslc_data_data_chunk)



#--------------------Write Bone info to precede mesh data


#start with 4-byte longint "bone_number", ie number of bones

bone_number_int = int(len(bone_list))

bone_number_longint = struct.pack('<i', bone_number_int)

z = open('write_float.dat', 'wb')
marshal.dump(bone_number_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
bone_number_int_again = y.read(4)
w.write(bone_number_int_again)





#-----now list out bone names


for i in range(0, len(bone_list)):
    bone_length_w = bone_namelength_list[i]
    bone_name_w = bone_list[i]
    i_bonelength_int = int(bone_length_w)
    i_bonelength_longint = struct.pack('<i', i_bonelength_int)

#write bone length

    z = open('write_float.dat', 'wb')
    marshal.dump(i_bonelength_longint, z)
    z.close()
    y = open('write_float.dat', 'rb')
    y.read(5)
    i_bonelength_again = y.read(4)
    w.write(i_bonelength_again)


#write bone_name


    w.write(bone_name_w)


#write bone number

    i_bone_index = bone_number_index_list[i]
    i_bone_int = int(i_bone_index)
    i_bone_longint = struct.pack('<i', i_bone_int)

    z = open('write_float.dat', 'wb')
    marshal.dump(i_bone_longint, z)
    z.close()
    y = open('write_float.dat', 'rb')
    y.read(5)
    i_bone_again = y.read(4)
    w.write(i_bone_again)




#Now write number of verts in 4-byte longint


vert_num_longint = struct.pack('<i', vert_num_int_total)

z = open('write_float.dat', 'wb')
marshal.dump(vert_num_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
vert_num_int_again = y.read(4)
w.write(vert_num_int_again)

#Now write 39 in 4-byte longint, this indicates its got animation, otherwise its 37, need to condition this


three_nine = 39


three_nine_int = int(three_nine)

three_nine_longint = struct.pack('<i', three_nine_int)

z = open('write_float.dat', 'wb')
marshal.dump(three_nine_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
three_nine_int_again = y.read(4)
w.write(three_nine_int_again)


#----------------------Now to write mesh data


#Group 1 MESH - three 4-byte floats (IEEE Singleint) per tris from "mesh_float_list".

#Now read and write verts 3 times


for i in range(0,len(mesh_float_list)):
    mesh_num = mesh_float_list[i]
    z = open('write_float.dat', 'wb')
    mesh_float = float(mesh_num)
    z_float = struct.pack('f', mesh_float)
    marshal.dump(z_float, z)
    z.close()
    y = open('write_float.dat', 'rb')
    y.read(5)
    mesh_num_float_again = y.read(4)
    w.write(mesh_num_float_again)





#Group 2 Skinweights - 16 bytes per tris, skinweights for 3 bones (4-byte float), then four bone index numbers 1-byte (chars)

end_e = 0

for i in range(0,vert_num_int_total):
    
    
    for e in range (0, 3):
        e = e + end_e
        vert_weight = skinweight_list[e]
        z = open('write_float.dat', 'wb')
        vert_weight_float = float(vert_weight)
        z_float = struct.pack('f', vert_weight_float)
        marshal.dump(z_float, z)
        z.close()
        y = open('write_float.dat', 'rb')
        y.read(5)
        vert_weight_float_again = y.read(4)
        print 'e = ', e
        print 'vert_weight_float_again =', vert_weight_float_again
        w.write(vert_weight_float_again)
        e = e + 1


    for f in range (0, 4):
        f = f + e
        bone_number = skinweight_list[f]
        print 'f = ', f
        print 'bone_number = ', bone_number
        bone_num_f = int(bone_number)
        bone_num_int = struct.pack('<B', bone_num_f)

#---------Write 1-byte  char int here 


        z = open('write_float.dat', 'wb')
        marshal.dump(bone_num_int, z)
        z.close()
        y = open('write_float.dat', 'rb')
        y.read(5)
        bone_num_int_again = y.read(1)
        w.write(bone_num_int_again)
        if f < 4:
            f = f + 1
    end_e = e + 4


#Group 3 MESHnormals three 4-byte floats per tris 

for i in range(0,len(meshnormal_float_list)):
    mesh_num = meshnormal_float_list[i]
    z = open('write_float.dat', 'wb')
    mesh_float = float(mesh_num)
    z_float = struct.pack('f', mesh_float)
    marshal.dump(z_float, z)
    z.close()
    y = open('write_float.dat', 'rb')
    y.read(5)
    mesh_num_float_again = y.read(4)
    w.write(mesh_num_float_again)





#Group 4 UV Coordinates two 4-byte floats per tris 


for i in range(0,len(uv_float_list)):
    mesh_num = uv_float_list[i]
    z = open('write_float.dat', 'wb')
    mesh_float = float(mesh_num)
    z_float = struct.pack('f', mesh_float)
    marshal.dump(z_float, z)
    z.close()
    y = open('write_float.dat', 'rb')
    y.read(5)
    mesh_num_float_again = y.read(4)
    w.write(mesh_num_float_again)



#Then there is the title of the Material for the mesh.   Need to do this

#write 4-byte longint zero

zero_longint = struct.pack('<i', zero_int)

z = open('write_float.dat', 'wb')
marshal.dump(zero_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
zero_int_again = y.read(4)
w.write(zero_int_again)


#---then write one in 4-byte longint

one = 1


one_int = int(one)

one_longint = struct.pack('<i', one_int)

z = open('write_float.dat', 'wb')
marshal.dump(one_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
one_int_again = y.read(4)
w.write(one_int_again)

#---Now write texture name path length in 4-byte longint

texture_path_length_int = int(texture_path_length)

texture_path_length_longint = struct.pack('<i', texture_path_length_int)

z = open('write_float.dat', 'wb')
marshal.dump(texture_path_length_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
texture_path_int_again = y.read(4)
w.write(texture_path_int_again)

#---write texture name from 

w.write(texture_path)



#Then things get weird. After the name of the Material is a 4-byte longint number. Divide this by 3 to get the number of faces. 

#Then the facenumber data follows, three 2-byte integers per face. 




#-----------write face total times 3

total_faces_x_3 = 3 * total_faces

total_faces_x_3_int = int(total_faces_x_3)

total_faces_x_3_longint = struct.pack('<i', total_faces_x_3_int)

z = open('write_float.dat', 'wb')
marshal.dump(total_faces_x_3_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
total_faces_x_3_int_again = y.read(4)
w.write(total_faces_x_3_int_again)

#------------------------then go to correct location to start reading face data

g.seek(start_face_data)

#---------------------Now get number of verts per face

for i in range(0, total_faces):
    g.read(2)
    number_for_face = g.read(1)
    print 'number for face at end = ', number_for_face
    number_for_face_int = int(number_for_face)
    g.read(1)
    start_number = g.tell()
                  

#----------Now read and write face verts number_for_face times, This is bad only 3 vert tris' are allowed in DOW.  
#----------My cylinder example has some 4-vert faces , polys I guess.  Need to see if Blender can convert them 
#----------to tris only.

    for k in range(0,number_for_face_int):

        for i in range(1,endoffile_int):
            vert_position = g.tell()
            count_comma = 1 + count_comma
            is_comma = g.read(1)
            if is_comma == ',' or is_comma == ';':
                count_comma = count_comma - 1
                g.seek(start_number)
                vert_num = g.read(count_comma)
                vert_num_i = int(vert_num)
                vert_num_int = struct.pack('<h', vert_num_i)

#---------Write 2-byte Longint here 


                z = open('write_float.dat', 'wb')
                marshal.dump(vert_num_int, z)
                z.close()
                y = open('write_float.dat', 'rb')
                y.read(5)
                vert_num_int_again = y.read(2)
                w.write(vert_num_int_again)
                g.read(2)
                start_number = g.tell()
                count_comma = 0
                break 


#first = 'first'

#w.write(first)


#write the 2-byte 00


zero_int_byte = struct.pack('<h', zero_int)
z = open('write_float.dat', 'wb')
marshal.dump(zero_int_byte, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
zero_int_again = y.read(2)
w.write(zero_int_again)


#second = 'second'
#w.write(second)

#write 2-byte vert_num_total

vert_num_int_total_byte = struct.pack('<h', vert_num_int_total)
z = open('write_float.dat', 'wb')
marshal.dump(vert_num_int_total_byte, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
vert_num_int_again = y.read(2)
w.write(vert_num_int_again)


#third = 'third'
#w.write(third)


#write 16 zeros

zero_longint = struct.pack('<i', zero_int)

z = open('write_float.dat', 'wb')
marshal.dump(zero_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
zero_int_again = y.read(4)

for i in range(0,4):
    w.write(zero_int_again)

w_end_mslc_data_data = w.tell()






#---------------------------------Now Write BVOL----------------------------
DATA = 'DATA'
BVOL = 'BVOL'

w.write(DATA)
w.write(BVOL)
start_bvolskel_ver = w.tell()

#write 4-byte longint two

two_longint = struct.pack('<i', two_int)

z = open('write_float.dat', 'wb')
marshal.dump(two_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
two_int_again = y.read(4)

#Get back to BVOL Chunk, BVOL Version 2

w.write(two_int_again)


#now write chunk size of 61

sixtyone = 61
sixtyone_int = int(sixtyone)
sixtyone_longint = struct.pack('<i', sixtyone_int)


z = open('write_float.dat', 'wb')
marshal.dump(sixtyone_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
sixtyone_int_again = y.read(4)


#Write BVOL chunk size 61

w.write(sixtyone_int_again)
w.write(zero_int_again)  #0000 namesize
bvol_chunk_start = w.tell()

#Now write one byte char 01

char_hex_01 = binascii.unhexlify('01')

w.write(char_hex_01)

#Now write three floats for coordinates

z = open('write_float.dat', 'wb')
zero_float = float(zero)
z_float = struct.pack('f', zero_float)
marshal.dump(z_float, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
zero_float_again = y.read(4)

#write three floats for coordinates for BVOL center, length divided by two.

x_max = max(x_vert_num_list)
x_min = min(x_vert_num_list)
x_length = x_max - x_min
x_length = (x_length *1.1)/2

z = open('write_float.dat', 'wb')
x_length_float = float(x_length)
z_float = struct.pack('f', x_length_float)
marshal.dump(z_float, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
x_length_float_again = y.read(4)


y_max = max(y_vert_num_list)
y_min = min(y_vert_num_list)
y_length = y_max - y_min
y_length = (y_length * 1.1)/2

z = open('write_float.dat', 'wb')
y_length_float = float(y_length)
z_float = struct.pack('f', y_length_float)
marshal.dump(z_float, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
y_length_float_again = y.read(4)


z_max = max(z_vert_num_list)
z_min = min(z_vert_num_list)
z_length = z_max - z_min
z_length = (z_length * 1.1)/2

z = open('write_float.dat', 'wb')
z_length_float = float(z_length)
z_float = struct.pack('f', z_length_float)
marshal.dump(z_float, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
z_length_float_again = y.read(4)


w.write(x_length_float_again) 
w.write(y_length_float_again)
w.write(z_length_float_again)

#---------------------------------------old zeros for origin---wrong!
#w.write(zero_float_again) 
#w.write(zero_float_again)
#w.write(zero_float_again)

#Now write three floats for lengths based on max and min vert coordinate times 1.1

x_max = max(x_vert_num_list)
x_min = min(x_vert_num_list)
x_length = x_max - x_min
x_length = (x_length * 1.1)/2

z = open('write_float.dat', 'wb')
x_length_float = float(x_length)
z_float = struct.pack('f', x_length_float)
marshal.dump(z_float, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
x_length_float_again = y.read(4)


y_max = max(y_vert_num_list)
y_min = min(y_vert_num_list)
y_length = y_max - y_min
y_length = (y_length * 1.1)/2

z = open('write_float.dat', 'wb')
y_length_float = float(y_length)
z_float = struct.pack('f', y_length_float)
marshal.dump(z_float, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
y_length_float_again = y.read(4)


z_max = max(z_vert_num_list)
z_min = min(z_vert_num_list)
z_length = z_max - z_min
z_length = (z_length * 1.1)/2

z = open('write_float.dat', 'wb')
z_length_float = float(z_length)
z_float = struct.pack('f', z_length_float)
marshal.dump(z_float, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
z_length_float_again = y.read(4)


w.write(x_length_float_again) 
w.write(y_length_float_again)
w.write(z_length_float_again)



#Now write scale matrix
#1,0,0

z = open('write_float.dat', 'wb')
one_float = float(one)
z_float = struct.pack('f', one_float)
marshal.dump(z_float, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
one_float_again = y.read(4)



w.write(one_float_again)
w.write(zero_float_again)
w.write(zero_float_again)

#0,1,0
w.write(zero_float_again)
w.write(one_float_again)
w.write(zero_float_again)

#0,0,1
w.write(zero_float_again)
w.write(zero_float_again)
w.write(one_float_again)



#-------------------------------------Done With MSLC BVOL



#-----------------Now write chunk sizes and MSLC

mslc = 'MSLC'


w_end = w.tell()

mslc_size = w_end - start_mslc_chunk_int
mslc_size_int = int(mslc_size)

mslc_size_longint = struct.pack('<i', mslc_size_int)

z = open('write_float.dat', 'wb')
marshal.dump(mslc_size_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
mslc_int_again = y.read(4)

#w.seek(28)
#w.write(mslc)

w.seek(mslc_chunk_size_location_int)


w.write(mslc_int_again)

thirteen = 13
thirteen_int = int(thirteen)
thirteen_longint = struct.pack('<i', thirteen_int)


z = open('write_float.dat', 'wb')
marshal.dump(thirteen_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
thirteen_int_again = y.read(4)


#--------------need to fix this, the space at the end is causing the 20 error, needs to be hex 00

ex.seek(135)

space_marine = ex.read(13)
#space_marine = 'Space_Marine '


w.write(thirteen_int_again)
w.write(space_marine)






#-------------------Now write MSLC/data/data chunk size

#-----------------------This needs to be fixed, plus 13 is cheesy
mslc_data_size = w_end_mslc_data_data - start_mslc_data_data_chunk_int + 13
mslc_data_size_int = int(mslc_data_size)

mslc_data_size_longint = struct.pack('<i', mslc_data_size_int)

z = open('write_float.dat', 'wb')
marshal.dump(mslc_data_size_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
mslc_data_int_again = y.read(4)

mslc_data_data_chunk_siz_loc = start_mslc_data_data_chunk_int - 21 #--8 plus offset of 13

mslc_data_data_chunk_siz_loc_int = int(mslc_data_data_chunk_siz_loc)

w.seek(mslc_data_data_chunk_siz_loc_int)
w.write(mslc_data_int_again)









w.seek(w_end)

#--------------------------------Now write MSGR Data/Data chunk after MSLC

w.write(DATA)
w.write(DATA)

#write version one longint.
one_longint = struct.pack('<i', one_int)

z = open('write_float.dat', 'wb')
marshal.dump(one_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
one_int_again = y.read(4)

#Get back to MSGRDATADATA Chunk, write Version 1

w.write(one_int_again)
start_msgr_data_chunksize = w.tell()
#placeholder for chunksize
w.write(DATA)
w.write(zero_int_again)
msgr_data_start = w.tell()



#now write longint number of meshes, one for now, need to fix later
w.write(one_int_again)

#now mesh namelength-------------13 for Space_Marine, need to fix later

w.write(thirteen_int_again)
w.write(space_marine)

#--------------------------------Write 0 Longint

w.write(zero_int_again)
neg_01_FF = binascii.unhexlify('FF')

#--------------------------------Write -1 Longint

w.write(neg_01_FF)
w.write(neg_01_FF)
w.write(neg_01_FF)
w.write(neg_01_FF)

w_end = w.tell()

msgr_data_chunk_size = w_end - msgr_data_start

msgr_data_chunk_size_int = int(msgr_data_chunk_size)
msgr_data_chunk_size_longint = struct.pack('<i', msgr_data_chunk_size_int)


z = open('write_float.dat', 'wb')
marshal.dump(msgr_data_chunk_size_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
msgr_data_chunk_size_int_again = y.read(4)


w.seek(start_msgr_data_chunksize)

w.write(msgr_data_chunk_size_int_again)

#-------------------------------------------------Now write MSGR/BVOL and MSGR chunk size

#---------------------------------Now Write MSGR BVOL----------------------------
w.seek(w_end)

DATA = 'DATA'
BVOL = 'BVOL'

w.write(DATA)
w.write(BVOL)
start_bvolskel_ver = w.tell()

#write 4-byte longint two

two_longint = struct.pack('<i', two_int)

z = open('write_float.dat', 'wb')
marshal.dump(two_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
two_int_again = y.read(4)

#Get back to BVOL Chunk, BVOL Version 2

w.write(two_int_again)


#now write chunk size of 61

sixtyone = 61
sixtyone_int = int(sixtyone)
sixtyone_longint = struct.pack('<i', sixtyone_int)


z = open('write_float.dat', 'wb')
marshal.dump(sixtyone_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
sixtyone_int_again = y.read(4)


#Write BVOL chunk size 61

w.write(sixtyone_int_again)
w.write(zero_int_again)  #0000 namesize
bvol_chunk_start = w.tell()

#Now write one byte char 01

char_hex_01 = binascii.unhexlify('01')

w.write(char_hex_01)

#Now write three floats for coordinates

z = open('write_float.dat', 'wb')
zero_float = float(zero)
z_float = struct.pack('f', zero_float)
marshal.dump(z_float, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
zero_float_again = y.read(4)


#write three floats for coordinates for BVOL center, length divided by two.

x_max = max(x_vert_num_list)
x_min = min(x_vert_num_list)
x_length = x_max - x_min
x_length = (x_length *1.1)/2

z = open('write_float.dat', 'wb')
x_length_float = float(x_length)
z_float = struct.pack('f', x_length_float)
marshal.dump(z_float, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
x_length_float_again = y.read(4)


y_max = max(y_vert_num_list)
y_min = min(y_vert_num_list)
y_length = y_max - y_min
y_length = (y_length * 1.1)/2

z = open('write_float.dat', 'wb')
y_length_float = float(y_length)
z_float = struct.pack('f', y_length_float)
marshal.dump(z_float, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
y_length_float_again = y.read(4)


z_max = max(z_vert_num_list)
z_min = min(z_vert_num_list)
z_length = z_max - z_min
z_length = (z_length * 1.1)/2

z = open('write_float.dat', 'wb')
z_length_float = float(z_length)
z_float = struct.pack('f', z_length_float)
marshal.dump(z_float, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
z_length_float_again = y.read(4)


w.write(x_length_float_again) 
w.write(y_length_float_again)
w.write(z_length_float_again)



#--------------------------------------old zeros, wrong!
#w.write(zero_float_again) 
#w.write(zero_float_again)
#w.write(zero_float_again)









#Now write three floats for lengths

z = open('write_float.dat', 'wb')
one_float = float(one)
z_float = struct.pack('f', one_float)
marshal.dump(z_float, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
one_float_again = y.read(4)

#Now write three floats for lengths based on max and min vert coordinate times 1.1

x_max = max(x_vert_num_list)
x_min = min(x_vert_num_list)
x_length = x_max - x_min
x_length = (x_length * 1.1)/2

z = open('write_float.dat', 'wb')
x_length_float = float(x_length)
z_float = struct.pack('f', x_length_float)
marshal.dump(z_float, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
x_length_float_again = y.read(4)


y_max = max(y_vert_num_list)
y_min = min(y_vert_num_list)
y_length = y_max - y_min
y_length = (y_length * 1.1)/2

z = open('write_float.dat', 'wb')
y_length_float = float(y_length)
z_float = struct.pack('f', y_length_float)
marshal.dump(z_float, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
y_length_float_again = y.read(4)


z_max = max(z_vert_num_list)
z_min = min(z_vert_num_list)
z_length = z_max - z_min
z_length = (z_length * 1.1)/2

z = open('write_float.dat', 'wb')
z_length_float = float(z_length)
z_float = struct.pack('f', z_length_float)
marshal.dump(z_float, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
z_length_float_again = y.read(4)


w.write(x_length_float_again) 
w.write(y_length_float_again)
w.write(z_length_float_again)



#Now write scale matrix
#1,0,0

w.write(one_float_again)
w.write(zero_float_again)
w.write(zero_float_again)

#0,1,0
w.write(zero_float_again)
w.write(one_float_again)
w.write(zero_float_again)

#0,0,1
w.write(zero_float_again)
w.write(zero_float_again)
w.write(one_float_again)



#-------------------------------------Done With MSGR BVOL



#-----------------Now write MSGR chunk sizes


w_end = w.tell()

#----------------This needs to change now that SKEL varies

msgr_size = w_end - start_msgr_chunk_int
msgr_size_int = int(msgr_size)

msgr_chunksize_address = start_msgr_chunk_int - 8
msgr_chunksize_address_int = int(msgr_chunksize_address)

msgr_size_longint = struct.pack('<i', msgr_size_int)

z = open('write_float.dat', 'wb')
marshal.dump(msgr_size_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
msgr_int_again = y.read(4)

#w.seek(28)
#w.write(mslc)
w.seek(msgr_chunksize_address_int)
w.write(msgr_int_again)







#-----------------Now write RSGM chunk sizes



rsgm_size = w_end - 148
rsgm_size_int = int(rsgm_size)

rsgm_size_longint = struct.pack('<i', rsgm_size_int)

z = open('write_float.dat', 'wb')
marshal.dump(rsgm_size_longint, z)
z.close()
y = open('write_float.dat', 'rb')
y.read(5)
rsgm_int_again = y.read(4)

w.seek(123)
w.write(one_int_again)
w.write(rsgm_int_again)






print 'RSGM, MSGR, MSLC, BVOL, and SKEL Chunks Complete'
print 'm_list = ', m_list

w.close()
ex.close()

#Next thing to do, get MSLC BVOL, MSGR DATA and BVOL  markers in. See "Marker Notes"


# Next thing to do, fix annoying problem with "end of meshnormals" text screwing up loop in the tris only file
