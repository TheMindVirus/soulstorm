#Script to convert whm to sgm files
# for Dawn of War Object Editor
 
import tkFileDialog
import binascii

import Tkinter

from Tkconstants import *
Hint = Tkinter.Tk()
frame = Tkinter.Frame(Hint, relief=RIDGE, borderwidth=2)
frame.pack(fill=BOTH,expand=1)
label = Tkinter.Label(frame, text="OPEN Hint \n This tool can open .whes for troops, structures, environment, and sky models in the data/art/ebps path")
label2 = Tkinter.Label(frame, text="File Use \n The file will be saved as a .ebp file which can be opened in the Object Editor")
label.pack(fill=X, expand=1)
label2.pack(fill=X, expand=1)
button = Tkinter.Button(frame,text="Close Hints",command=Hint.destroy)
button.pack(side=BOTTOM)

 

filetoparse = tkFileDialog.askopenfilename(filetypes=[("whe", "whe")], title = 'Choose a .whe file to convert to .ebp format')


 

filetowrite = tkFileDialog.asksaveasfilename(filetypes=[("ebp", "ebp")], title = 'Save exported .ebp file as.....', defaultextension = ".ebp")


w = open(filetowrite,'wb')

g = open(filetoparse,'rb')
s = open('bonelist.dat','wb')
relic_header = g.read(24)
w.write(relic_header) 
g.read()
endoffile = g.tell() - 20
endoffile_int = int(endoffile)
g.seek(18)
space = g.read(1)      #This make a 00 variable that is written after bone and marker names be careful that all whms have 00 at this address.
g.seek(28)

burnfile = g.read(4)
ver_loc = g.tell()
ver_read = g.read(4)
g.seek(ver_loc)
ver_read3 = g.read(3)
burnfile_str = str(burnfile)
print burnfile_str

zero = 0
zero_int = int(zero)


import struct
import marshal


g.seek(24)                  #This part puts the file in the right position if there is no Burn info
if burnfile_str == 'FBIF':  #this part puts the file in right position if it has Burn Info in front If you change this make sure you change checksize_int at the end.
    g.seek(36)               
    checkFBIFsize = struct.unpack('<L', g.read(4))[0]
    checkFBIFsize_int = int(checkFBIFsize)
    burnfile_data_end = 57 + checkFBIFsize_int
    g.seek(burnfile_data_end)

end_SEUI_data = 10

#------------<<<<<<<<<<<<<<<<<Start Main Loop Here>>>>>>>>>>>>>>>>>>>>>>---------------------

for i in range(1,1000): 
    checkposition = g.tell()
    checktype = g.read(4) 
    checkID = g.read(4)
    ver_loc = g.tell()
    checkver = struct.unpack('<L', g.read(4))[0] 
    checksize = struct.unpack('<L', g.read(4))[0]
    namesize_loc = g.tell()
    namesize_read = g.read(4)
    g.seek(namesize_loc) 
    checknamesize = struct.unpack('<L', g.read(4))[0] 
    noname_position = g.tell()
    name = g.read(checknamesize)
    position = g.tell()
    header_dif = position-checkposition
    header_dif_int = int(header_dif)
    oldchunk_start = g.tell()
    oldchunk_size = checksize
        
    if checknamesize == '0000':
        nextchunk = noname_position + checksize
    if checknamesize != '0000':
        nextchunk = position + checksize 
    if checktype == 'FOLD':
        if checknamesize == '0000':
            nextchunk = noname_position
        if checknamesize != '0000':
            nextchunk = position 
 
    print 'CHunk located at', checkposition 
    print checktype
    print checkID
    print 'Version', checkver
    print 'Chunk Size', checksize
    print 'Name Size',checknamesize
    print name
    print 'next chunk starts at', nextchunk




    if checkID == 'REBP':
        g.seek(checkposition)
        rsgm_ver = ver_read
        rsgm_ver_loc = ver_loc
        print 'header_dif_int = ', header_dif_int
        RSGM_header = g.read(header_dif_int)
        rsgm_write_start = w.tell()
        rsgm_write_ver_loc = rsgm_write_start + 8
        w.write(RSGM_header)
        start_rsgm_chunk = w.tell()
        print 'REBP header printed'


    if checkID == 'EVCT' or checkID == 'CLST' or checkID == 'CONL' or checkID == 'MODL' or checkID == 'MTRE' or checkID == 'SEUI':
        g.seek(checkposition)
        print 'header_dif_int = ', header_dif_int
        SSHR_header = g.read(header_dif_int)
        w.write(SSHR_header)
        print 'SSHR header printed'
        checksize_int = int(checksize)
        print 'size checksize_int is ', checksize_int 
        SSHR_data = g.read(checksize_int)
        w.write(SSHR_data)
        end_SEUI_data = w.tell()


    if checkID == 'ANIM':
        g.seek(checkposition)
        print 'header_dif_int = ', header_dif_int
        SSHR_header = g.read(header_dif_int)
        w_anim_start = w.tell()
        w_anim_ver_start = w_anim_start + 7
        w_anim_ver_start_int = int(w_anim_ver_start)
        
        w.write(SSHR_header)
        end_w_header = w.tell()

#-----------change version in ANIM to 1

        one = 1
        one_int = int(one)
        w.seek(w_anim_ver_start_int)
        marshal.dump(one_int, w)
        w.seek(w_anim_ver_start_int)
        em = 'M'
        w.write(em)
        w.seek(end_w_header)
        print 'SSHR header printed'

#-----------print data in ANIM
        checksize_int = int(checksize)
        print 'size checksize_int is ', checksize_int 
        SSHR_data = g.read(checksize_int)
        w.write(SSHR_data)
        end_SEUI_data = w.tell()


#-------------------------------------Loop Breaking Here

    if nextchunk > endoffile:
        Hint.mainloop()
        break
#-------------------------------------End Loop Breaking



    if checkID == 'ACTS':
        g.seek(checkposition)
        skel_start = g.tell()        
        skel_ver = ver_read
        skel_ver_loc = ver_loc
        fold = 'FOLD'
        info = 'INFO'
        actr = 'ACTR'
        bone = 'ACTN'

#skel folder
        skel_header = g.read(header_dif_int)
        skel_start_write = w.tell()
        write_skel_ver_loc = skel_start_write + 8
        w.write(skel_header)
        start_skel_chunk = w.tell()
        w.seek(skel_start_write)
        w.write(fold)
        w.write(actr)
        w.seek(start_skel_chunk)

#--------------------Reading checkbonetotal may be wrong, may need to change to 2000 or something non-specific.

        g_loc = g.tell()
        bonetotal_read = g.read(4)
        g.seek(g_loc)
        checkbonetotal = struct.unpack('<L', g.read(4))[0]
        checkbonetotal_int = int(checkbonetotal)
#        w.write(bonetotal_read)

        for k in range(0,checkbonetotal_int):
            m = 0
            g_loc = g.tell()
            print 'file located at', g_loc            
            checkbonenamesize = struct.unpack('<L', g.read(4))[0]
            bonename_start = g.tell()
            bonename_3_byte = g.read(3)
            g.seek(bonename_start)
            bonename = g.read(checkbonenamesize)
            start_actn_data = g.tell()
            look_for_zero = struct.unpack('<L', g.read(4))[0]
            look_for_zero_int = int(look_for_zero)


#bonename means action name


#ACTR data size integer needs to be determined based on 
#reading the number of motions 4-byte longint integer after action name (except for default)
#then counting the number of motions till the namesize for the next action.

#----------------------------------Now need to read to end of ACTN signified by longint 2 (only for Default)
            if look_for_zero_int != 0:
                g.seek(start_actn_data)
            total_motions = struct.unpack('<L', g.read(4))[0]
            total_motions_int = int(total_motions)
            print 'total_motions = ', total_motions_int
            for m in range (0, total_motions_int):
                m = m + 1
                motion_namelength = struct.unpack('<L', g.read(4))[0]
                motion_namelenth_location  = g.tell()
                print 'motion namelength location', motion_namelenth_location
                print 'm = ', m
                action = g.read(motion_namelength)
                lists_motions = struct.unpack('<L', g.read(4))[0]  #this four bytes is usually 1 and it means action
                lists_motions_int = int(lists_motions)

#--------------Check to see if this motion has 12 bytes of data instead of usual 8
                twelve_check_start = g.tell() # This where file will go if regular 8 byte motion
                g.read(4)
                twelve_check_4 = g.tell()
                check_twelve = g.read(3)
                g.seek(twelve_check_4)           # this is where file will go if 12 byte motion
                check_twelve_alnum = check_twelve.isalnum()
                check_twelve_alnum_str = str(check_twelve_alnum)
                if check_twelve_alnum_str == 'True':     # if true then it means its 8 byte like usual
                    g.seek(twelve_check_start)
                                
                


#-----------------This condition in case there is a submotion with a motion namesize directly after it with no lists_motions 4 bytes

                if lists_motions_int == 1 or lists_motions_int == 0:
                    startmotion = g.tell()
                    print 'startmotion location =', startmotion
                    submotion_namelength = struct.unpack('<L', g.read(4))[0]
                    print 'lists_motions_int =', lists_motions_int
                    print 'submotion_namelength =', submotion_namelength
                    motion = g.read(submotion_namelength)
                    motionlocation = g.tell()
                    print 'motionlocation =', motionlocation
                    if m == total_motions_int:
                        check_motion_zero = struct.unpack('<L', g.read(4))[0]
                        check_motion_zero_int = int(check_motion_zero)
                        g.seek(motionlocation)
                        if check_motion_zero_int == 0:
                            g.read(4)
                        
                  

                if lists_motions_int == 3 and m == total_motions_int:
                    check_for_end_zero_loc = g.tell()
                    check_for_end_zero = struct.unpack('<L', g.read(4))[0]
                    check_for_end_zero_int = int(check_for_end_zero)
                    if check_for_end_zero_int != 0:
                        g.seek(check_for_end_zero_loc)


            end_actn_data = g.tell()
            is_data = g.read(4)
            g.seek(end_actn_data)
       
            actn_chunk_size = end_actn_data - start_actn_data
            actn_chunk_size_int = int(actn_chunk_size)
            g.seek(start_actn_data)            
            bone_data = g.read(actn_chunk_size_int)
            if is_data == 'DATA':
                g.read(4)
            data = 'DATA'
            w.write(data)
            w.write(bone)
            w_loc = w.tell()

#correction here for space after name convention in .sgm files
            w.write(ver_read3)
            w.write(ver_read)
            correct_bone_name_size = checkbonenamesize + 1
            correct_bone_name_size_int = int(correct_bone_name_size)
            marshal.dump(correct_bone_name_size_int, w)
            w.write(bonename)
            w.write(space)
            w_namesize_loc = w.tell()
            w.seek(w_loc)
            w.write(ver_read3)

#ACTR data size integer needs to be determined based on 
#reading the number of motions 4-byte longint integer after action name (except for default)
#then counting the number of motions till the namesize for the next action.




            marshal.dump(actn_chunk_size_int,w)            # this chunksize needs to be longint later
            w.seek(w_loc)
            w.write(ver_read)
            w.seek(w_namesize_loc)
            w.write(bone_data)
            actn_data_loc = w.tell()

#--------------------minimum chunk size needs to be 8
            if actn_chunk_size_int < 8:
                w.seek(w_loc)
                w.write(ver_read3)
                eight_diff = 8 - actn_chunk_size_int
                eight_diff_int = int(eight_diff)                 
                eight = actn_chunk_size_int + eight_diff_int
                print '8 = ', eight
                eight_int = int(eight)
                marshal.dump(eight_int,w)            # this chunksize needs to be longint later
                w.seek(w_loc)
                w.write(ver_read)
                w.seek(actn_data_loc)
                for e in range(0, eight_diff_int):
                    w.write(space)

            if is_data == 'DATA':
                wrong_location = g.tell()
                location_fix = wrong_location - 4
                location_fix_int = int(location_fix)
                g.seek(location_fix_int)
                break



        nextchunk = g.tell()
        print 'SEUI chunk located at', nextchunk
        
#Skel chunksize write        
        end_skel_chunk = w.tell()
        skel_chunksize = end_skel_chunk - start_skel_chunk
        skel_chunksize_int = int(skel_chunksize)
        w.seek(write_skel_ver_loc)
        w.write(ver_read3)
        marshal.dump(skel_chunksize_int, w)

        print 'Start ACTR Chunk', start_skel_chunk
        print 'end ACTR chunk', end_skel_chunk
        print 'skel_chunksize_int', skel_chunksize_int
        print 'write_skel_ver_loc', write_skel_ver_loc

        w.seek(write_skel_ver_loc)
        w.write(ver_read)
        w.seek(end_skel_chunk)                
            

#write new chunksize to REBP


        
        end_skel_chunk = w.tell()
        skel_chunksize = end_skel_chunk - start_rsgm_chunk
        skel_chunksize_int = int(skel_chunksize)
        w.seek(rsgm_write_ver_loc)
        w.write(ver_read3)
        marshal.dump(skel_chunksize_int, w)
        w.seek(rsgm_write_ver_loc)
        w.write(ver_read)
        w.seek(end_skel_chunk) 






    if nextchunk > endoffile:
        Hint.mainloop()
        break




    g.seek(nextchunk)


skel_chunksize = end_SEUI_data - start_rsgm_chunk
skel_chunksize_int = int(skel_chunksize)
w.seek(rsgm_write_ver_loc)
w.write(ver_read3)
marshal.dump(skel_chunksize_int, w)
w.seek(rsgm_write_ver_loc)
w.write(ver_read)
w.seek(end_skel_chunk) 


