Mudflap's WHE to EBP converter
Version 1.0 Beta
by Mudflap
http://games.groups.yahoo.com/group/nurglings/


Description:  This is a tool that allows you to convert WHE format files from
Dawn of War, Winter Assault, and Dark Crusade into EBP files that can be opened in the DOW Modtools Object Editor. 
WHE files provide instructions on how troop and building models are supposed to behave ingame.
This tool can be used extract this information and look at it in an EBP file in the Object Editor.
Using the Object Editor you can then change animations, motions,actions, and FX to change
how the model behaves in the game.  This is also useful if you want to
make a new unit behave like existing units in the game, or save time by using 
an existing WHE as a starting point for making changes for a new unit.

What to do:

1) use the DOW modtools Mod Packager to extract whe files from WXPData-Whm-High.sga, W40kData-Whm-High.sga, or DXP2Data-Whm-High.sga files.  

2) Save the zip file wherever you want the tool to go.  Open the Mudflaps_WHE_to_EBP_Converter folder
   then doubleclick on Mudflaps_WHH_to_EBP_Converter.exe.
3) A dialog box will ask you what .WHE file you want to convert.
4) A dialog box will ask what .EBP file you want to save to, save it in the Datageneric\art\ebps\races\...etc
folder for your mod so you can open it in the Object Editor if your mod is in the pipeline.ini file.
5) IMPORTANT!!!!! ---- Your new .EBP file will not open in the Object Editor without a .sgm file with
the same name.  To address this, take the "Put_me_in_datageneric_and_change_my_name.sgm" and put it in the proper folder
in your mods Datageneric directory and change the name of the .sgm to the same name as your new .EBP.
6) Open your .EBP file in the Object Editor.  If you use the .sgm file above you will see
a pink box.  That is a good thing.  It means that your EBP works.  The pink box
is just a dummy and has no animations or relation to the whm for the unit you are working on.  It is there 
to make the Object Editor think there is model that is associated with your EBP.
7) Make a small change to your EBP then save it.
The Object Editor will automatically update the associated WHE in your mod folder with the new info.
If you don't have a WHE in your mod folder, then it will create a new WHE based on your EBP.


Disclaimers

This tool is in no way endorsed by Relic, THQ, or Games Workshop.  Although the Chunky Viewer was 
very helping for understanding the chunk information.
The code for this tool can be read in the associated .py file using Python 2.4.
This tool is open source for any non-commercial purpose.
If you have any questions please feel free to email Mudflap at mudflapcentral@hotmail.com
The maker of this tool is in no way responsible for any computer problems that users may have 
when using this tool, Python, or the Object Editor.
This tool is in Beta form and created by a hobbyist using computers with 
Intel processors and may not work as intended on all systems.


This tool is an offshoot of an ongoing effort to make a GMAX exporter for DOW SGMs using Python.  
If you can help, please join the following forum.

http://www.dowdomains.co.uk/forums/viewforum.php?f=27



