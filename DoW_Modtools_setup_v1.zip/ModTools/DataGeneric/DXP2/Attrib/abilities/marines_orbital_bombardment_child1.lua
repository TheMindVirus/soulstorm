----------------------------------------
-- File: 'abilities\marines_orbital_bombardment_child1.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\marines_orbital_bombardment_children.lua]])
MetaData = InheritMeta([[abilities\marines_orbital_bombardment_children.lua]])

GameData["child_ability_name"] = "marines_orbital_bombardment_child2"
GameData["initial_delay_time"] = 7.20000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
