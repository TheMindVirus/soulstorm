----------------------------------------
-- File: 'abilities\marines_inquisition_child04.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\marines_inquisition_child01.lua]])
MetaData = InheritMeta([[abilities\marines_inquisition_child01.lua]])

GameData["child_ability_name"] = "marines_inquisition_child05"
GameData["initial_delay_time"] = 17.40000
GameData["random_offset"] = 8.00000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
