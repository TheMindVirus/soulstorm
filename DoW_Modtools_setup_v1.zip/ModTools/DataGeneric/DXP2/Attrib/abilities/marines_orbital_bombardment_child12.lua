----------------------------------------
-- File: 'abilities\marines_orbital_bombardment_child12.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\marines_orbital_bombardment_children.lua]])
MetaData = InheritMeta([[abilities\marines_orbital_bombardment_children.lua]])

GameData["area_effect"]["weapon_damage"]["armour_damage"]["armour_piercing_types"]["entry_06"]["armour_piercing_value"] = 40.10000
GameData["child_ability_name"] = "marines_orbital_bombardment_child13"
GameData["initial_delay_time"] = 24.50000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
