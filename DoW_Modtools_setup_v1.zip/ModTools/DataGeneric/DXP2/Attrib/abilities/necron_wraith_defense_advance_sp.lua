----------------------------------------
-- File: 'abilities\necron_wraith_defense_advance_sp.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\necron_wraith_defense.lua]])
MetaData = InheritMeta([[abilities\necron_wraith_defense.lua]])



MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
