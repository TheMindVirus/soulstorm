----------------------------------------
-- File: 'abilities\chaos_daemon_strength_daemon_prince.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\chaos_daemon_strength.lua]])
MetaData = InheritMeta([[abilities\chaos_daemon_strength.lua]])

GameData["area_effect"]["weapon_damage"]["modifiers"]["modifier_03"]["modifier"]["target_type_name"] = "chaos_daemon_prince_sword"
GameData["area_effect"]["weapon_damage"]["modifiers"]["modifier_04"]["modifier"]["target_type_name"] = "chaos_daemon_prince_sword"
GameData["ui_info"]["help_text_list"]["text_01"] = "$575402"
GameData["ui_info"]["help_text_list"]["text_03"] = "$575400"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, rangeStart = 575400, rangeEnd = 575449, }
MetaData["$METACOLOURTAG"] = 
{

}
