----------------------------------------
-- File: 'ebps\environment\gameplay\guard_detection_field_sp.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\gameplay\guard_detection_field.lua]])
MetaData = InheritMeta([[ebps\environment\gameplay\guard_detection_field.lua]])

GameData["sight_ext"]["keen_sight_radius"] = 12.00000
GameData["sight_ext"]["sight_radius"] = 12.00000
GameData["suicide_ext"]["lifetime"] = 20.00000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
