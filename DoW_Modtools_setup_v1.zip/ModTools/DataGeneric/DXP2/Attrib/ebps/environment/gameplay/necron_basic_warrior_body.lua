----------------------------------------
-- File: 'ebps\environment\gameplay\necron_basic_warrior_body.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\gameplay\necron_body.nil]])
MetaData = InheritMeta([[ebps\environment\gameplay\necron_body.nil]])

GameData["entity_blueprint_ext"]["animator"] = "Races/Necrons/Troops/Necron_Basic_Warrior"
GameData["entity_blueprint_ext"]["scale_x"] = 0.50000
GameData["entity_blueprint_ext"]["scale_z"] = 0.50000
GameData["modifier_ext"] = Reference([[ebpextensions\modifier_ext.lua]])


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
MetaData["modifier_ext"] = {desc = [[]], type = 4, category = [[]], dispval = [[]], }
