----------------------------------------
-- File: 'ebps\environment\gameplay\necron_destroyer_body.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\gameplay\necron_body.nil]])
MetaData = InheritMeta([[ebps\environment\gameplay\necron_body.nil]])

GameData["entity_blueprint_ext"]["animator"] = "Races/Necrons/Troops/Necron_Destroyer"
GameData["entity_blueprint_ext"]["scale_x"] = 0.50000
GameData["entity_blueprint_ext"]["scale_z"] = 0.50000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
