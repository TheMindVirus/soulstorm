----------------------------------------
-- File: 'ebps\environment\gameplay\guard_detection_field.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\gameplay\necron_solar_pulse.lua]])
MetaData = InheritMeta([[ebps\environment\gameplay\necron_solar_pulse.lua]])

GameData["ability_ext"]["abilities"]["ability_01"] = ""
GameData["suicide_ext"]["lifetime"] = 30.00000


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
