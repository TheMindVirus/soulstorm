----------------------------------------
-- File: 'ebps\environment\gameplay\nuke_orks_sp.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\gameplay\nuke.lua]])
MetaData = InheritMeta([[ebps\environment\gameplay\nuke.lua]])



MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
