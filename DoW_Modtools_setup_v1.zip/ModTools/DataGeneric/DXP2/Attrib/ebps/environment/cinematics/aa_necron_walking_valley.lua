----------------------------------------
-- File: 'ebps\environment\cinematics\aa_necron_walking_valley.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\cinematics\cinematics.lua]])
MetaData = InheritMeta([[ebps\environment\cinematics\cinematics.lua]])

GameData["entity_blueprint_ext"]["animator"] = "environment/Cinematics/aa_Necron_walk_valley"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
