----------------------------------------
-- File: 'ebps\environment\cinematics\shot1.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\cinematics\cinematics.lua]])
MetaData = InheritMeta([[ebps\environment\cinematics\cinematics.lua]])

GameData["entity_blueprint_ext"]["animator"] = "environment/Cinematics/Shot1"
GameData["sim_entity_ext"]["is_in_spatial_bucket"] = false


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
