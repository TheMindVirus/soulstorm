----------------------------------------
-- File: 'ebps\environment\ambient_fx\avatar_spawn_01.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\ambient_fx\ambient_fx.nil]])
MetaData = InheritMeta([[ebps\environment\ambient_fx\ambient_fx.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment/ambient_fx/Avatar_Spawn"
GameData["sim_entity_ext"]["is_in_spatial_bucket"] = true
GameData["type_ext"]["type_surface"] = Reference([[type_surface\tp_stone.lua]])


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
