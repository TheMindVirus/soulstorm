----------------------------------------
-- File: 'ebps\environment\ambient_fx\wind_med_01.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\ambient_fx\ambient_fx.nil]])
MetaData = InheritMeta([[ebps\environment\ambient_fx\ambient_fx.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment/ambient_fx/wind_gust_med_01"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
