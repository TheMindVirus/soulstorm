----------------------------------------
-- File: 'ebps\environment\all\carnage\carnage_tau_02.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\all\carnage\carnage.nil]])
MetaData = InheritMeta([[ebps\environment\all\carnage\carnage.nil]])

GameData["entity_blueprint_ext"]["animator"] = "Environment\\All\\carnage_tau_02"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
